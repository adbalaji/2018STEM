BEFORE RUNNING THE PROGRAM

1. Download and install Anaconda 
	- https://www.anaconda.com/download/

RUN EVERYTHING IN THE ANACONDA PROMPT

2. Create the RDKit environment
	- RDKit 
		- conda create -c rdkit -n my-rdkit-env rdkit

3. Activate the RDKit environment
	- Mac and Linux Users
		- source activate my-rdkit-env
	- Windows Users
		- activate my-rdkit-env

4. Install the following modules before running the program using the method listed (Anaconda comes preloaded with a few of these modules already)
	- Tkinter
	- Requests
		- pip install requests
	- Pillow
		- pip install Pillow
	- Sklearn
		- pip install sklearn
	- Scipy
		- pip install scipy
	- Numpy
		- pip install numpy

5. Change the directory of variables in the GUI and SVM document
	
	- GUI.py
		- s = (insert path for 'CID_se_sparse.txt')
	- SVM.py
		- f = (insert path for 'Features_Values.txt')
		- s = (insert path for 'CID_se_sparse.txt')
	- KNC.py 
		- f = (insert path for 'Features_Values.txt')
		- s = (insert path for 'CID_se_sparse.txt')
	- DCT.py
		- f = (insert path for 'Features_Values.txt')
		- s = (insert path for 'CID_se_sparse.txt')

6. Save all of the changes to the files

RUNNING THE PROGRAM

7. Type the following into the Anaconda prompt: python GUI.py

PROGRAM INFORMATION

2018 Version 1.8 (Beta) 

Created by Adhitya Balaji and Mohit Manchella

Email: adhitya.balaji@outlook.com

def DCT(a, b, c, sid):
	import numpy as np
	from sklearn.neighbors import KNeighborsClassifier
	from sklearn.model_selection import KFold
	from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score)
	from sklearn import tree
	from scipy.sparse import csr_matrix

	kf = KFold(n_splits = 5, shuffle = True, random_state = 2)

	f = "C:\\Users\\Adhitya Balaji\\Features_Values.txt"
	s = "C:\\Users\\Adhitya Balaji\\CID_se_sparse.txt"
	
	feat = np.loadtxt(f, delimiter = ' ').astype(int)
	se = np.loadtxt(s, delimiter = ' ').astype(int)
	
	feat_row = feat[:,0]
	feat_column = feat[:,1]
	feat_data = feat[:,2]

	se_row = se[:,0]
	se_column = se[:,1]
	se_data = se[:,2]

	se_mat = csr_matrix((se_data, (se_row-1, se_column-1)), (2097, 5868))

	feat_mat = csr_matrix((feat_data, (feat_row-1, feat_column-1)),(2097, 2048))
	
	sum_se = se_mat.sum(axis=0)
	ags = np.argsort(sum_se)
	ags = ags.tolist()
	ags = ags[0]
	ags = ags[::-1]
	
	data_X = feat_mat
	data_Y = se_mat[:,sid]

	a = a 

	b = b

	c = c


	r_avg = []
	a_avg = []
	p_avg = []
	f_avg = []


	r_list = []
	r1_list = []
	a_list = []
	p_list = []
	p1_list = []
	f_list = []
	model_list = []

	for train_index, test_index in kf.split(data_X):

		tr = data_X[train_index,:]
		tr_label = np.ravel( data_Y[train_index].todense() )
		te = data_X[test_index,:]
		te_label = np.ravel( data_Y[test_index].todense() )
		
		clf = tree.DecisionTreeClassifier(max_depth = a, min_samples_split = b, min_samples_leaf = c)

		clf.fit(tr, tr_label)
		data_pred = clf.predict(te)

		model_list.append(clf)
		
		#TP
		tp = np.where((data_pred==0)&(te_label==0))[0].shape[0]
		#TN
		tn = np.where((data_pred==1)&(te_label==1))[0].shape[0]
		#FP
		fp = np.where((data_pred==0)&(te_label==1))[0].shape[0]
		#FN
		fn = np.where((data_pred==1)&(te_label==0))[0].shape[0]
		
		tp_index = test_index[np.where((data_pred==0)&(te_label==0))[0]]

		tn_index = test_index[np.where((data_pred==1)&(te_label==1))[0]]

		fp_index = test_index[np.where((data_pred==0)&(te_label==1))[0]]	
		
		fn_index = test_index[np.where((data_pred==1)&(te_label==0))[0]]
		
		
		#Recall
		R = recall_score(te_label, data_pred, average='binary')	
		r_list.append(R)
	
		r1 = recall_score(te_label, data_pred, average='binary', pos_label = 0)	
		r1_list.append(r1)

		#Accuracy
		A = accuracy_score(te_label, data_pred)
		a_list.append(A)

		#Precision	
		P = precision_score(te_label, data_pred, average='binary')
		p_list.append(P)

		p1 = precision_score(te_label, data_pred, average='binary', pos_label = 0)
		p1_list.append(p1)
	
		#F1 Score
		F = f1_score(te_label, data_pred, average='binary')
		f_list.append(F)
		
		#F1 Score
		F = f1_score(te_label, data_pred, average='binary')
		f_list.append(F)
	

	r_bar = ("%.4f"%(sum(r_list)/kf.get_n_splits(data_X)))
	r1_bar = ("%.4f"%(sum(r1_list)/kf.get_n_splits(data_X)))
	a_bar = ("%.4f"%(sum(a_list)/kf.get_n_splits(data_X)))
	p_bar = ("%.4f"%(sum(p_list)/kf.get_n_splits(data_X)))
	p1_bar = ("%.4f"%(sum(p1_list)/kf.get_n_splits(data_X)))
	f_bar = ("%.4f"%(sum(f_list)/kf.get_n_splits(data_X)))

	return r_bar, r1_bar, a_bar, p_bar, p1_bar, f_bar, model_list 
	
	

import tkinter as tk
from tkinter import *
from PIL import Image, ImageTk
import tkinter.simpledialog as tksdg
from PIL import Image
import requests
import io
import glob, os
from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem
import numpy as np
import pdb
from scipy.sparse import csr_matrix


class Window(Frame):
	def __init__(self, master = None):
		Frame.__init__(self, master, bg = "black")
		self.master = master
		self.id_inter = 0
		
		s = "C:\\Users\\Adhitya Balaji\\CID_se_sparse.txt"
		se = np.loadtxt(s, delimiter = ' ').astype(int)
	
		se_row = se[:,0]
		se_column = se[:,1]
		se_data = se[:,2]
	
		se_mat = csr_matrix((se_data, (se_row-1, se_column-1)), (2097, 5868))
	
		sum_se = se_mat.sum(axis=0)

		# read document
		self.Dict_SE_ID = {};
		self.Set_SE = [];
		f = open('SE_uniq_ID_name.py', 'r')
		f = f.read()
		f = f.split('\n')[:-1]

		for i in range(0, len(f)):
			se_id_list = f[i].split(';')
			self.Dict_SE_ID.update( {se_id_list[1]:int(se_id_list[0])} )
			frq = sum_se[0, i]
			self.Set_SE.append( se_id_list[1] + ' '  + ( str( frq  ) ) )

		# Create a Tkinter variable
		self.tkvar = StringVar(root)
		# Dictionary with options
		self.tkvar.set(self.Set_SE[1082]) # set the default option
		
		self.model_list =[]
			
		self.text = Label(self, text = "Created by: Adhitya Balaji and Mohit Manchella", bg = "black", fg = "red", font = ("Times New Roman", 13))
		self.text.pack()
		self.text.place(x = 0, y = 550)
		
		self.text = Label(self, text = "2018 Version 1.8 (Beta)", bg = "black", fg = "red", font = ("Times New Roman", 13))
		self.text.pack()
		self.text.place(x = 0, y = 575)


		self.init_window()
	
	#Creation of Initial Window
	def init_window(self):
      		#Instructions
		self.text = Label(self, text = "Instructions:", font = ("Times New Roman", 16), bg = "black", fg = "red")
		self.text.pack()
		self.text.place(x = 0, y = 0)
		
		#Step 1
		self.text = Label(self, text = "1. Enter the CID", font = ("Times New Roman", 13), bg = "black", fg = "red")
		self.text.pack()
		self.text.place(x = 0, y = 40 )
		
		#Step 2
		self.text = Label(self, text = "2. Show the representation, Drug and IUPAC name, and SMILES", font = ("Times New Roman", 13), bg = "black", fg = "red")
		self.text.pack()
		self.text.place(x = 0, y = 80 )

		#Step 3
		self.text = Label(self, text = "3. Pick the side effect from the drop down list", font = ("Times New Roman", 13), bg = "black", fg = "red")
		self.text.pack()
		self.text.place(x = 0, y = 200 )
		
		#Step 4
		self.text = Label(self, text = "4. Run the SVM, KNeighbors, or Decision Tree classifier", font = ("Times New Roman", 13), bg = "black", fg = "red")
		self.text.pack()
		self.text.place(x = 0, y = 265 )

		#Step 5
		self.text = Label(self, text = "5. Predict if the drug has the side effect", font = ("Times New Roman", 13), bg = "black", fg = "red")
		self.text.pack()
		self.text.place(x = 0, y = 450 )
		
		#IU Logo
		filename_1 = ImageTk.PhotoImage(file = "IU.jpg")
		background_label_1 = Label(root, image = filename_1, bg = "black")
		background_label_1.image = filename_1
		background_label_1.place(x=1100, y=0)

		#CTSI Logo
		filename = ImageTk.PhotoImage(file = "CTSI.jpg")
		background_label = Label(root, image = filename, bg = "black")
		background_label.image = filename
		background_label.place(x=950, y=500)

		#Changing the title of the master widget
		self.master.title("Compound ID Lookup")
      
      		#Allowing the widget to take the full space of the root window
		self.pack(fill = BOTH, expand = 1)
      
      		#Creating a button instance
		idButton = Button(self, text = "Compound ID", command = self.client_search, bg = "red")
		imgButton = Button(self, text = "Representation", command = self.client_show, bg = "red")
		iupButton = Button(self, text = "IUPAC Name", command = self.client_iup, bg = "red")
		namButton = Button(self, text = "Drug Name", command = self.client_nam, bg = "red")
		smiButton = Button(self, text = "SMILES", command = self.client_smile, bg = "red")
		cvButton = Button(self, text = "SVM Classification", command = self.client_c, bg = "red")
		kncButton = Button(self, text = "KNearestNeighbors Classification", command = self.client_knc, bg = "red")
		dctButton = Button(self, text = "Decision Tree Classification", command = self.client_dct, bg = "red")
		pdButton = Button(self, text = "Side Effect Prediction", command = self.client_pd, bg = "red")
     
      		#Placing the button on the window
		
		idButton.place(x = 125, y = 40)
		imgButton.place(x = 0, y = 110)
		iupButton.place(x = 125, y = 110)
		namButton.place(x = 0, y = 140)
		smiButton.place(x = 0, y = 170)
		cvButton.place(x = 0, y = 290)
		kncButton.place(x = 125, y = 290)
		dctButton.place(x = 325, y = 290)
		pdButton.place(x = 0, y = 475)
		
		#Creating a popMenu
		
		
		popupMenu = OptionMenu(self , self.tkvar, *self.Set_SE)
		popupMenu.config(bg = "red")
		popupMenu["menu"].config(bg = "black", fg = "red", font = ("Times New Roman", 13))
		popupMenu.place(x = 0, y = 230 )

		# link function to change dropdown
		self.tkvar.trace('w', self.change_dropdown)

		#Create a menu instance
		menu = Menu(self.master)
		self.master.config(menu = menu)
		
		#Create the file object
		file = Menu(menu)
		
		#Adds a command to the menu 
		file.add_command(label = "Reset", command = self.client_reset)
		file.add_command(label = "Exit", command = self.client_exit)
		
		#Added "file" to our menu
		menu.add_cascade(label = "File", menu = file)
		
		self.l1 = self.tkvar.get().split(' ')
		if (len(self.l1) == 3):
			self.l2 = self.l1[0] + ' ' + self.l1[1]
		if (len(self.l1) == 2):
			self.l2 = self.l1[0]
		
	def client_show(self):
		link = "https://pubchem.ncbi.nlm.nih.gov/image/imagefly.cgi?cid=?&width=300&height=300" 
		new = list( link )
		new[56] = str( self.id_inter )
		link = ''.join(new)
		response = requests.get(link)
		img = Image.open(io.BytesIO(response.content))
		img.save("00001.png","PNG")
		render = ImageTk.PhotoImage(Image.open("00001.png"))
		imglabel = Label(self, image=render, bg = "black")
		imglabel.image = render
		imglabel.place(x = 500, y = 0)
	
	def client_search(self):
		self.id_inter = tksdg.askinteger(title = 'Compound ID', prompt = 'Enter the CID')
		self.text = Label(self, text = "CID: " + str(self.id_inter), bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 500, y = 320)
	
	def client_nam(self):
		sm_1 = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug_view/data/compound/?/JSON/?response_type=display'
		new_2 = list( sm_1 )
		new_2[61] = str( self.id_inter )
		sm_1 = ''.join(new_2)
		sm_1 = requests.get(sm_1)
		sm_1 = sm_1.text
		
		if(('"RecordType": "CID",' in sm_1)):
			sm_1 = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug_view/data/compound/?/JSON/?response_type=display'
			new_2 = list( sm_1 )
			new_2[61] = str( self.id_inter )
			sm_1 = ''.join(new_2)
			sm_1 = requests.get(sm_1)
			sm_1 = sm_1.text
			beg_ind_1 = sm_1.index('"Name": "3D Conformer') + 51
			end_ind_1 = sm_1.index('"NumValue"')
			nam = sm_1[beg_ind_1:end_ind_1]
			
			if (',' in nam):
				nam = sm_1[beg_ind_1:end_ind_1].split(',')[0]
			elif (':' in nam):
				nam = nam.split(':')[1]
				nam =  nam.split(',')[0]
			self.text = Label(self, text = "Drug Name: " + str(nam), bg = "black", fg = "red", font = ("Times New Roman", 12))
			self.text.pack()
			self.text.place(x = 500, y = 340)
			
	def client_iup(self):
			sm_1 = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/?/record/SDF/?record_type=2d&response_type=display'
			new_2 = list( sm_1 )
			new_2[55] = str( self.id_inter )
			sm_1 = ''.join(new_2)
			sm_1 = requests.get(sm_1)
			sm_1 = sm_1.text
			beg_ind_1 = (sm_1.index('PUBCHEM_IUPAC_OPENEYE_NAME') + 28)
			end_ind_1 = (sm_1.index('PUBCHEM_IUPAC_CAS_NAME') - 5)
			nam = sm_1[beg_ind_1:end_ind_1]
			self.text = Label(self, text = "IUPAC: " + str(nam), bg = "black", fg = "red", font = ("Times New Roman", 12))
			self.text.pack()
			self.text.place(x = 500, y = 390)
		
	def client_reset(self):
		python = sys.executable
		os.execl(python, python, * sys.argv)
		restart_program()

	def client_smile(self):
		sm = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/?/record/SDF/?record_type=2d&response_type=display'
		new_1 = list( sm )
		new_1[55] = str( self.id_inter )
		sm = ''.join(new_1)
		sm = requests.get(sm)
		sm = sm.text
		beg_ind = (sm.index('SMILE') + 8)
		end_ind = (sm.index('PUBCHEM_OPENEYE_ISO') - 5)
		self.smi = sm[beg_ind:end_ind]
		self.text = Label(self, text = "SMILES: " + str(self.smi), bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 500, y = 365)

	def client_knc(self):
		from KNearestNeighbors import KNC
		
		k = tksdg.askinteger(title = 'K Value', prompt = 'Enter your K Value for the Model')
		sid = int(self.Dict_SE_ID[self.l2] - 1)
	
		r_bar, r1_bar, a_bar, p_bar, p1_bar, f_bar, self.model_list = KNC( k, sid )

		self.text = Label(self, text = 'Positive Recall Score: ' + r_bar, bg = "black", fg = "red", font = ("Times New Roman", 12)) 
		self.text.pack()
		self.text.place(x = 0, y = 320)
		
		string1 = 'Negative Recall Score: ' + str(r1_bar)
		self.text = Label(self, text = string1, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 0, y = 360)
		
		self.text = Label(self, text = 'Accuracy Score: ' + a_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 0, y = 410)
		
		self.text = Label(self, text = 'Positive Precision Score: ' + p_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 250, y = 320)

		self.text = Label(self, text ='Negative Precision Score: ' + str(p1_bar), bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 250, y = 360)
			
		self.text = Label(self, text = 'F1 Score: ' + f_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 250, y = 410)

	def client_dct(self):
		from DCT import DCT

		a = tksdg.askinteger(title = 'Max Depth', prompt = 'Enter your Max Depth of the Tree')
		b = tksdg.askinteger(title = 'Min Samples for Internal Node', prompt = 'Enter the minimum samples required to split an internal node')
		c = tksdg.askinteger(title = 'Min Samples for Leaf', prompt = 'Enter the minimum samples required to be at a leaf node')
		sid = int(self.Dict_SE_ID[self.l2] - 1)

		r_bar, r1_bar, a_bar, p_bar, p1_bar, f_bar, self.model_list  = DCT(a, b, c, sid)

		self.text = Label(self, text = 'Positive Recall Score: ' + r_bar, bg = "black", fg = "red", font = ("Times New Roman", 12)) 
		self.text.pack()
		self.text.place(x = 0, y = 320)
		
		string1 = 'Negative Recall Score: ' + r1_bar
		self.text = Label(self, text = string1, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 0, y = 360)
		
		self.text = Label(self, text = 'Accuracy Score: ' + a_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 0, y = 410)
		
		self.text = Label(self, text = 'Positive Precision Score: ' + p_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 250, y = 320)

		self.text = Label(self, text ='Negative Precision Score: ' + p1_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 250, y = 360)
			
		self.text = Label(self, text = 'F1 Score: ' + f_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 250, y = 410)
		
	def client_c(self):
		from SVM import SVM

		c = tksdg.askinteger(title = 'C Value', prompt = 'Enter your C Value for the Model')
		ke = tksdg.askstring('Kernel', 'Would you like a linear or poly kernel?')
		d = tksdg.askinteger('Polynomial Degree', 'Degree of 1 or 2? If using a linear kernel enter 0.')
		sid = int(self.Dict_SE_ID[self.l2] - 1)
	
		r_bar, r1_bar, a_bar, p_bar, p1_bar, f_bar, self.model_list  = SVM(sid, c, ke, d)
		
		self.text = Label(self, text = 'Positive Recall Score: ' + r_bar, bg = "black", fg = "red", font = ("Times New Roman", 12)) 
		self.text.pack()
		self.text.place(x = 0, y = 320)
		
		string1 = 'Negative Recall Score: ' + r1_bar
		self.text = Label(self, text = string1, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 0, y = 360)
		
		self.text = Label(self, text = 'Accuracy Score: ' + a_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 0, y = 410)
		
		self.text = Label(self, text = 'Positive Precision Score: ' + p_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 250, y = 320)

		self.text = Label(self, text ='Negative Precision Score: ' + p1_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 250, y = 360)
			
		self.text = Label(self, text = 'F1 Score: ' + f_bar, bg = "black", fg = "red", font = ("Times New Roman", 12))
		self.text.pack()
		self.text.place(x = 250, y = 410)
		
	def client_pd(self):
		m = Chem.MolFromSmiles(self.smi)
		fp = AllChem.GetMorganFingerprintAsBitVect (m, 2, 2048)
		self.arr = np.zeros((1,))
		DataStructs.ConvertToNumpyArray(fp, self.arr)
		self.arr = np.matrix(self.arr)
		self.Pred_label = [ list(model.predict( self.arr ))[0] for model in self.model_list ]
		self.Pred_label = str( max(set(self.Pred_label), key = self.Pred_label.count) )

		if (self.Pred_label == '0'):
			label = 'Negative'
		else:
			label = 'Positive'

		self.text = Label(self, text = "Prediction Results: " + label, bg = "black", fg = "red", font = ("Times New Roman", 18, "bold"))
		self.text.pack()
		self.text.place(x = 500, y = 415)

	def change_dropdown(self, *args):
		self.l1 = self.tkvar.get().split(' ')
		if (len(self.l1) == 3):
			self.l2 = self.l1[0] + ' ' + self.l1[1]
		if (len(self.l1) == 2):
			self.l2 = self.l1[0]

		print( self.tkvar.get()+':  '+ str( self.Dict_SE_ID[self.l2]  ) )
 		
	def client_exit(self):
		exit()
		
      
root = tk.Tk()

#Size of the window
root.geometry("1200x600")

app = Window(root)


root.mainloop()
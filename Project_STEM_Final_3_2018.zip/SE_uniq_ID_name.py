1;Acute abdomen
2;Abdominal cramps
3;Distended abdomen
4;Abdominal neoplasm NOS
5;Pain abdominal
6;Congenital abnormality NOS
7;Multiple congenital anomalies
8;Spontaneous abortion
9;Missed abortion
10;Septic abortion
11;Abruptio placentae
12;Abscess
13;Acanthosis nigricans
14;Accident
15;Traffic accident
16;Acidosis
17;Lactic acidosis
18;Renal tubular acidosis
19;Respiratory acidosis
20;Acne vulgaris
21;Acquired immunodeficiency syndrome
22;Acrodynia
23;Acromegaly
24;Ectopic ACTH syndrome
25;Pancreatitis acute
26;Acute phase reaction
27;Acute tonsillitis
28;Acute yellow liver atrophy
29;Stokes-Adams syndrome
30;Addison's disease
31;Adenitis
32;Adenocarcinoma
33;Adenoma
34;Adenovirus infection
35;Adhesion
36;Adjustment disorders
37;Unspecified disorder of adrenal glands
38;Hyperadrenocorticism
39;Insufficiency adrenal
40;Aerophagy
41;Afibrinogenemia
42;Aggressive behavior
43;Agnosia
44;Agoraphobia
45;Agranulocytosis
46;AIDS dementia complex
47;Airway obstruction NOS
48;Albinism
49;Albuminuria
50;Alcohol withdrawal delirium
51;Alcohol intoxication
52;Alcoholism
53;Alkalosis
54;Respiratory alkalosis
55;Atopic rhinitis
56;Alopecia
57;Extrinsic allergic alveolitis
58;Alzheimer's disease
59;Amblyopia
60;Amelia
61;Amenorrhea
62;Amnesia
63;Retrograde amnesia
64;Infection of amniotic cavity
65;Amyloidosis
66;Anaphylaxis
67;Anemia
68;Anemia aplastic
69;Hemolytic anemia
70;Autoimmune hemolytic anemia
71;Hypochromic anemia
72;Macrocytic anemia
73;Megaloblastic anemia
74;Anemia neonatal
75;Refractory anemia
76;RAEB
77;Sickle-cell anemia
78;Sideroblastic anemia
79;Anencephaly
80;Aneurysm
81;Artery dissection
82;Anger
83;Angina pectoris
84;Prinzmetal angina
85;Unstable angina
86;Angioedema
87;Anhidrosis
88;Animal bite
89;Anisocoria
90;Anophthalmos
91;Anorexia
92;Anosmia
93;Anovulation
94;Anoxia
95;Anthrax
96;Anuria
97;Anus disorder
98;Imperforate anus
99;Anxiety
100;Anxiety disorder
101;Aneurysm aortic
102;Aortic coarctation
103;Aortic disorder
104;Aortic valve insufficiency
105;Stenosis aortic valve
106;Aphakia
107;Aphasia
108;Aphonia
109;Apnea
110;Appendicitis
111;Appetite disorders
112;Apraxia
113;Arachnoiditis
114;Arcus senilis
115;Cardiac arrhythmia
116;Arrhythmia sinus
117;Arterial insufficiency
118;Arterial occlusive disease
119;Arteriosclerosis
120;Arteriovenous fistula
121;Arteritis
122;Arthralgia
123;Arthritis
124;Gouty arthritis
125;Infectious arthritis
126;Psoriatic arthritis
127;Arthritis rheumatoid
128;Arthropathy neurogenic
129;Phonological disorder
130;Ascariasis
131;Ascites
132;Aspergillosis
133;Asphyxia
134;Assault
135;Asthenia
136;Asthenopia
137;Asthma
138;Astrocytoma
139;Ataxia
140;Atelectasis
141;Atherosclerosis
142;Athetosis
143;Sports injury
144;Fibrillation atrial
145;Flutter atrial
146;Atrioventricular block
147;Atrioventricular dissociation
148;Autistic disorder
149;Autoimmune disorder
150;Automatism
151;Azoospermia
152;Back injury
153;Pain back
154;Background diabetic retinopathy
155;Bacteremia
156;Bacterial infection
157;Pneumonia bacterial
158;Bacteriuria
159;Balanitis
160;Balanoposthitis
161;Barrett's esophagus
162;Bartholin's cyst
163;Basilar artery syndrome
164;Beckwith-Wiedemann syndrome
165;Behavior disorder
166;Mental disorder NOS
167;Benign neoplasm of skin
168;Benign prostatic hypertrophy
169;Bile duct disorders
170;Cholestasis extrahepatic
171;Atresia biliary
172;Biliary tract disease
173;Bipolar disorder
174;Blackwater fever
175;Bladder calculus
176;Bladder neoplasms malignant
177;Unspecified disorder of bladder
178;Bladder distension
179;Bladder neck obstruction
180;Neoplasm bladder
181;Bladder neurogenic
182;Blast cell crisis
183;Blastomycosis
184;Blepharitis
185;Blepharoconjunctivitis
186;Blepharoptosis
187;Blepharospasm
188;Bullae
189;Clotting
190;Defect coagulation (NOS)
191;Thrombocytopathy
192;Blood pressure abnormal
193;Bloodshot eye
194;Body temperature altered
195;Osteopathy
196;Metabolic bone disorders
197;Bone marrow disorder
198;Marrow hyperplasia
199;Bone neoplasm
200;Bowen's disease
201;Brain abscess
202;Concussion
203;Unspecified condition of brain
204;Metabolic encephalopathy
205;Edema cerebral
206;Brain neoplasm NOS
207;Malignant breast neoplasm
208;Cyst breast
209;Breast disorder
210;Breast feeding
211;Breast swelling
212;Breech presentation
213;Bronchial disorder
214;Spasm bronchial
215;Bronchiectasis
216;Bronchiolitis
217;Bronchiolitis obliterans
218;Bronchitis
219;Bronchopneumonia
220;Bronchopulmonary dysplasia
221;Bruxism
222;Bulimia
223;Block bundle branch
224;Burkitt's lymphoma
225;Burning mouth syndrome
226;Burn
227;Chemical burn
228;Bursitis
229;Cachexia
230;Calcinosis
231;Calciphylaxis
232;Malignant neoplasm NOS
233;Candidiasis
234;Cutaneous moniliasis
235;Mucocutaneous candidiasis
236;Oral candidiasis
237;Vaginal moniliasis
238;Capillary fragility
239;Carbuncle
240;Carcinoid tumor
241;Carcinoma
242;Carcinoma in situ
243;Malignant neoplasm of colon
244;Endometrial neoplasms malignant
245;Malignant neoplasm of larynx
246;Adenocarcinoma of prostate
247;Rectal carcinoma
248;Malignant skin neoplasm NOS
249;Basal cell carcinoma
250;Alveolar cell carcinoma
251;Non-small cell lung cancer
252;Renal cell carcinoma
253;Squamous cell carcinoma
254;Cardiac output decreased
255;Tamponade cardiac
256;Dilated cardiomyopathy
257;Hypertrophic cardiomyopathy
258;Restrictive cardiomyopathy
259;Cardiovascular disorder
260;Thrombosis carotid artery
261;Carotid bruit
262;Carotid artery stenosis
263;Carpal tunnel syndrome
264;Cartilage disorders
265;Catalepsy
266;Cataplexy
267;Catatonia
268;Causalgia
269;Cellulitis
270;CNS disorder (NOS)
271;Central nervous system infection
272;Ataxia cerebellar
273;Cerebellar syndrome
274;Aneurysm intracranial
275;Cerebral arteritis
276;Embolism cerebral
277;Cerebral infarction
278;Transient ischemic attack
279;Cerebrospinal fluid rhinorrhea
280;Cerebrovascular disorder
281;Cervical polyp
282;Pain neck
283;Cervicitis
284;Occipital neuralgia
285;Cervix disorder
286;Cervical dysplasia
287;Erosion of cervix
288;Incompetence of cervix
289;Cervix neoplasms
290;Meibomian cyst
291;Cheilitis
292;Pain chest
293;Pleuritic pain
294;Chest wall pain
295;Cheyne-Stokes respiration
296;Chickenpox
297;Chlamydial infection
298;Choking
299;Cholangitis
300;Sclerosing cholangitis
301;Cholecystitis
302;Cholelithiasis
303;Cholestasis
304;Cholestasis intrahepatic
305;Chondrodystrophy
306;Chorea
307;Choriocarcinoma
308;Chorioretinitis
309;Choroiditis
310;Chromosome abnormality
311;Churg Strauss syndrome
312;Chylothorax
313;Claustrophobia
314;Lip cleft
315;Palate cleft
316;Clonus
317;Clostridia infections
318;Congenital clubfoot
319;Cluster headache
320;Tongue coated
321;Coccydynia
322;Cognitive disorder
323;Cold intolerance
324;Colitis
325;Colitis ulcerative
326;Collagen disorder
327;Colonic polyp
328;Colonic pseudo-obstruction
329;Color vision deficiencies
330;Comatose
331;Common cold
332;Infection
333;Compartment syndrome
334;Condylomata acuminata
335;Confusion
336;Unspecified disorder of conjunctiva
337;Conjunctival haemorrhage
338;Conjunctivitis
339;Conjunctivitis allergic
340;Conjunctivitis bacterial
341;Connective tissue disorder
342;Constipation
343;Contracture
344;Joint contracture
345;Contusion
346;Febrile convulsion
347;Corneal abrasion
348;Unspecified corneal disorder
349;Corneal dystrophy
350;Corneal edema
351;Opacity corneal
352;Ulcer corneal
353;Coronary atherosclerosis
354;Coronary heart disease
355;Thrombosis coronary
356;Coronary vasospasm
357;Corpus luteum cyst
358;Coughing
359;Cramp of limb
360;Unspecified disorder of cranial nerves
361;Craniosynostosis
362;Hypothyroidism congenital
363;Crohn's disease
364;Cryptococcus neoformans infection
365;Cryptorchidism
366;Cryptosporidiosis
367;Cushing's syndrome
368;Cutis laxa
369;Cyanosis
370;Disorder cyclothymic
371;Acne cystic
372;Cystitis
373;Cystocele
374;Cyst
375;Cytomegalovirus infection
376;Cytopenia
377;Dacryocystitis
378;Deafness
379;Sudden hearing loss
380;Sudden death
381;Libido decreased
382;Decubitus ulcer
383;Deglutition disorder
384;Dehydration
385;Delirium
386;Delusional disorders
387;Delusions
388;Vascular dementia
389;Demyelinating disorders
390;Demyelination
391;Dental caries
392;Hypoplasia enamel
393;Sensitive dentin
394;Depersonalization
395;Depression mental
396;Depressive disorder
397;Dermatitis
398;Exfoliative dermatitis
399;Drug eruption
400;Atopic dermatitis
401;Dermatitis contact
402;Fungal dermatitis
403;Dermatomyositis
404;Dermatophytosis
405;Scleroderma
406;Dermoid cyst
407;Developmental coordination disorder
408;Diabetes insipidus
409;Diabetes mellitus
410;Insulin-dependent diabetes mellitus
411;Non-insulin-dependent diabetes mellitus
412;Diabetic vascular disorder
413;Cataract diabetic
414;Ketoacidosis (diabetic)
415;Diabetic nephropathy
416;Diabetic neuropathy
417;Retinopathy diabetic
418;Diaper rash
419;Diarrhea
420;Gastrointestinal anomaly
421;Digitalis toxicity
422;Distention
423;Diplopia
424;Spondylodiscitis
425;Dislocation
426;Disseminated intravascular coagulation
427;Dissociative disorder
428;Diuresis
429;Diverticulitis
430;Diverticulum
431;Dizziness
432;Down's syndrome
433;Drooling
434;Drowsiness
435;Drug abuse
436;Drug allergy
437;Drug tolerance
438;Drug toxicity
439;Dry eye syndrome
440;Alveolar osteitis
441;Patent ductus arteriosus
442;Ulcer duodenal
443;Duodenitis
444;Dupuytren's contracture
445;Dwarfism
446;Dysarthria
447;Dysautonomia
448;Dysentery
449;Dysgeusia
450;Dyskinetic syndrome
451;Dysmenorrhea
452;Dyspepsia
453;Dyspnea
454;Dysthymic disorder
455;Abnormal labour
456;Idiopathic torsion dystonia
457;Dysuria
458;Unspecified disorder of ear
459;Earache
460;Eating disorder
461;Ecchymosis
462;Echolalia
463;Eclampsia
464;Ectromelia
465;Ectropion
466;Eczema
467;Edema
468;Oedema due to cardiac disease
469;Localised oedema
470;Effusion
471;Electric shock
472;Embolism
473;Amniotic fluid embolism
474;Fat embolism
475;Emotional disturbance NOS
476;Enanthema
477;Encephalitis
478;Acute disseminated encephalomyelitis
479;Encephalocele
480;Endocarditis
481;Subacute bacterial endocarditis
482;Endocrine disorder
483;Endometrial neoplasm
484;Hyperplasia endometrial
485;Endometriosis
486;Endometritis
487;Endophthalmitis
488;Enophthalmos
489;Enteritis
490;Enterocolitis
491;Pseudomembranous enterocolitis
492;Enuresis
493;Enzyme induction
494;Eosinophilia
495;Epicondylitis
496;Cyst epidermal
497;Toxic epidermal necrolysis
498;Epidermolysis bullosa
499;Epididymitis
500;Epiglottitis
501;Epilepsy
502;Tonic-clonic epilepsy
503;Myoclonic epilepsy
504;Epilepsy petit mal
505;Episcleritis
506;Epistaxis
507;Ergotism
508;Intertrigo candida
509;Eructation
510;Erysipelas
511;Erythema multiforme
512;Erythema nodosum
513;Palmar erythema
514;Erythrasma
515;Hyperplasia erythroid
516;Erythromelalgia
517;Achalasia esophageal
518;Esophageal atresia
519;Esophageal disease NOS
520;Esophageal motility disorder
521;Esophageal neoplasm NOS
522;Esophageal perforation
523;Esophageal spasm
524;Stenosis esophageal
525;Varices esophageal
526;Esophagitis
527;Reflux esophagitis
528;Exanthema
529;Excoriation
530;Exophthalmos
531;Extrapyramidal disorder
532;Extravasation
533;Eye abnormality
534;Eye burns
535;Eye disorder
536;Foreign body in eye
537;Hemorrhage eye
538;Eye infection
539;Eye infection viral
540;Eye injury
541;Penetrating eye injury
542;Unspecified disorder of eyelid
543;Face injury
544;Neuralgia facial
545;Facial pain
546;Facial paralysis
547;Factor XI deficiency
548;Failure to thrive
549;Fanconi syndrome
550;Fasciculation
551;Fasciitis
552;Fasting
553;Fat necrosis
554;Fatigue
555;Chronic fatigue syndrome
556;Liver fatty
557;Fear
558;Incontinence fecal
559;Impaction fecal
560;Feminization
561;Femur fracture
562;Femoral neck fracture
563;Fertilization
564;Fetal alcohol syndrome
565;Death fetal
566;Foetal disorder
567;Fetal distress
568;Fetal growth retardation
569;Premature rupture of membranes
570;Fever
571;Fever of unknown origin
572;Fibrocystic disease
573;Disease fibrocystic breast
574;Fibroma
575;Fibromyalgia
576;Fibrosis
577;Fissure anal
578;Fistula
579;Pain flank
580;Flatulence
581;Vitreous floaters
582;Fluorosis
583;Flushing
584;Cardiac flutter
585;Localised infection
586;Folic acid deficiency
587;Folliculitis
588;Food allergy
589;Food poisoning
590;Malformation foot NOS
591;Foot pain
592;Foot and mouth disease
593;Foramen ovale patent
594;Foreign body
595;Formication
596;Fracture
597;Stress fracture
598;Freckles
599;Frigidity
600;Fructose intolerance
601;Frustration
602;Intestinal functional disorder
603;Funnel chest
604;Furunculosis
605;Gagging
606;Unspecified disorder of gallbladder
607;Gangrene
608;Gas gangrene
609;Gastritis
610;Gastroenteritis
611;Gastroesophageal reflux disease
612;Gastrointestinal disorder
613;Hemorrhage gastrointestinal
614;Gastrointestinal neoplasm NOS
615;Unspecified disorder of female genital organs
616;Unspecified disorder of male genital organs
617;Female reproductive neoplasm
618;Gilbert's syndrome
619;Gingival disease
620;Hemorrhage gingival
621;Gingival hyperplasia
622;Hypertrophy gingival
623;Gingival recession
624;Gingivitis
625;Glaucoma
626;Angle closure glaucoma
627;Glioblastoma
628;Glioma
629;Globus hystericus
630;Glomerulitis
631;Glomerulonephritis
632;Membranoproliferative glomerulonephritis
633;Glomerulonephritis membranous
634;Focal glomerulosclerosis
635;Glossodynia
636;Glossitis
637;Geographic tongue
638;Glycosuria
639;Goiter
640;Goiter nodular
641;Gonorrhea
642;Gout
643;Vascular graft occlusion
644;Graft rejection
645;Graft versus host disease
646;Graft versus host reaction
647;Granuloma
648;Graves' disease
649;Guillain-Barre syndrome
650;Gynecomastia
651;Hair disorder
652;Halitosis
653;Hallucinations
654;Hamartoma
655;Hay fever
656;Head injury
657;Headache
658;Partial hearing loss
659;High frequency deafness
660;Sensorineural deafness
661;Arrest cardiac
662;Block heart
663;Heart malformation
664;Heart disorder
665;Cardiomegaly
666;Heart failure
667;Congestive heart failure
668;Heart murmur
669;Fetal heart rate
670;Myocardial rupture
671;Cardiac septal defect NOS
672;Atrial septal defect
673;Ventricular septal defect
674;Valvular heart disease NOS
675;Heartburn
676;Heat exhaustion
677;Heat stroke
678;Hemangioma
679;Hemarthrosis
680;Hematemesis
681;Hematochezia
682;Unspecified diseases of blood and blood-forming organs
683;Hematoma
684;Subdural hematoma
685;Hematuria
686;Hemeralopia
687;Hemianopsia
688;Hemimelia
689;Hemiparesis
690;Hemiplegia
691;Hemobilia
692;Hemochromatosis
693;Hemoglobinuria
694;Hemolysis
695;Syndrome hemolytic uremic
696;Hemopericardium
697;Hemoperitoneum
698;Hemophilia A
699;Hemoptysis
700;Hemorrhage
701;Haemorrhagic disorder
702;Hemorrhoids
703;Hemothorax
704;Coma hepatic
705;Encephalopathy hepatic
706;Hepatic vein thrombosis
707;Venoocclusive syndrome of the liver
708;Hepatitis
709;Hepatitis A
710;Hepatitis B
711;Alcoholic hepatitis
712;Chronic hepatitis
713;Hepatitis toxic
714;Hepatitis C
715;Hepatomegaly
716;Syndrome hepatorenal
717;Hepatosplenomegaly
718;Hereditary angioedema
719;Hernia
720;Diaphragmatic hernia
721;Inguinal hernia
722;Umbilical hernia
723;Herpangina
724;Herpes NOS
725;Herpes genital
726;Herpes labialis
727;Herpes simplex
728;Herpetic keratitis
729;Herpes zoster
730;Herpes zoster ophthalmicus
731;Herpes infection
732;Herpetic meningoencephalitis
733;Hiccup
734;Hip dislocation
735;Hip fracture
736;Coxalgia
737;Hirschsprung's disease
738;Hirsutism
739;Histiocytosis
740;Malignant histiocytosis
741;Histoplasmosis
742;Hoarseness
743;Hodgkin's disease
744;Homocystinuria
745;Hordeolum
746;Horner's syndrome
747;Hostility
748;Humerus fracture
749;Hunger
750;Hydatidiform mole
751;Polyhydramnios
752;Hydrocephalus
753;Hydronephrosis
754;Buphthalmos
755;Hydrops fetalis
756;Hydrothorax
757;Hyperalgesia
758;Hyperbilirubinemia
759;Hypercalcemia
760;Hypercalciuria
761;Hypercapnia
762;Hypercholesterolemia
763;Hyperemesis gravidarum
764;Hyperemia
765;Hyperesthesia
766;Hypergammaglobulinemia
767;Hyperglycemia
768;Nonketotic hyperglycemic-hyperosmolar coma
769;Hyperhidrosis
770;Hyperinsulinism
771;Hyperkalemia
772;Hyperlipidemia
773;Hypernatremia
774;Hyperostosis
775;Forestier disease
776;Hyperparathyroidism
777;Hyperparathyroidism secondary
778;Hyperphagia
779;Hyperplasia
780;Nodular regenerative hyperplasia
781;Hyperprolactinemia
782;Hypersensitivity
783;Cell-mediated immunological react
784;Immediate hypersensitivity
785;Hypersplenism
786;Blood pressure high
787;Hypertension malignant
788;Portal hypertension
789;Hypertension pulmonary
790;Renovascular hypertension
791;Hypertensive crisis
792;Hyperthyroidism
793;Hypertrichosis
794;Hypertriglyceridemia
795;Hypertrophy
796;Hypertrophy of breast
797;Salivary gland enlargement
798;Hyperventilation
799;Hypervitaminosis A
800;Hypesthesia
801;Hyphema
802;Hypoaldosteronism
803;Hypocalcemia
804;Hypocalciuria
805;Hypochondriasis
806;Hypoglycemia
807;Hypoglycemic coma
808;Hypogonadism
809;Hypohidrosis
810;Hypokalemia
811;Hypomenorrhea
812;Hyponatremia
813;Hypoparathyroidism
814;Hypopituitarism
815;Hypoproteinemia
816;Hypopyon
817;Hypotension
818;Orthostatic hypotension
819;Body temperature decreased
820;Hypothyroidism
821;Hypotrichosis
822;Hypovolemic shock
823;Hysteria
824;Ichthyoses
825;Ileitis
826;Illusion
827;Immune status
828;Angioimmunoblastic T-cell lymphoma
829;Unspecified immunity deficiency
830;Immune system disorder
831;Immunosuppression
832;Impacted cerumen
833;Impetigo
834;Bullous impetigo
835;Impulse control disorders
836;Syndrome inappropriate ADH
837;Incontinence
838;Libido increased
839;Infarction
840;Infection of kidney
841;Mononucleosis infectious
842;Infertility
843;Female infertility
844;Infertility male
845;Inflammation
846;Inflammatory bowel disease
847;Influenza
848;Insect bite NOS
849;Insomnia NEC
850;Insulin resistance
851;Insulinoma
852;Claudication intermittent
853;Intertrigo
854;Unspecified disorder of intestine
855;Obstruction intestinal
856;Perforation intestinal
857;Intestinal pseudo-obstruction
858;IUD expelled
859;Intussusception
860;Iridocyclitis
861;Iris disorder
862;Iritis
863;Irritable bowel syndrome
864;Irritability
865;Ischemia
866;Eye itching
867;Icterus
868;Jaundice neonatal
869;Obstructive jaundice
870;Diseases of the jaws
871;Arthropathy
872;Joint instability
873;Kaposi's varicelliform eruption
874;Kearns-Sayre syndrome
875;Keloid
876;Keratitis
877;Keratoacanthoma
878;Keratoconjunctivitis
879;Keratoconjunctivitis sicca
880;Keratoconus
881;Acquired keratoderma
882;Keratosis
883;Actinic keratosis
884;Seborrheic keratosis
885;Ketosis
886;Calculus of kidney
887;Necrosis kidney cortex
888;Nephropathy
889;Acute kidney failure
890;Kidney failure chronic
891;Renal neoplasms
892;Necrosis kidney papillary
893;Nephrosis lower nephron
894;Polycystic kidney
895;Klinefelter's syndrome
896;Kyphosis
897;Labor premature
898;Labyrinthine disorder
899;Labyrinthitis
900;Lacrimal disorder
901;Lacrimal duct obstruction
902;Lactose intolerance
903;Unspecified disease of larynx
904;Laryngeal edema
905;Laryngeal neoplasm
906;Laryngismus
907;Laryngitis
908;Laryngopharyngitis
909;Cerebrospinal fluid leakage
910;Learning disorders
911;Bundle branch block left
912;Left heart failure
913;Cramps of lower extremities
914;Leg pain
915;Leg ulcer
916;Fibroids
917;Lentigo
918;Leriche syndrome
919;Lethargy
920;Leukemia
921;Leukemia lymphocytic chronic
922;Myelosis erythremic
923;Lymphoid leukemia
924;Acute lymphocytic leukemia
925;Acute myelocytic leukemia
926;Leukemia myeloid
927;Chronic myeloid leukemia
928;Chronic phase chronic myeloid leukemia
929;Chronic myelomonocytic leukemia
930;Plasma cell leukemia
931;Acute promyelocytic leukemia
932;Reaction leukemoid
933;Diseases of white blood cells
934;Leukocytosis
935;Progressive multifocal leukoencephalopathy
936;Periventricular leukomalacia
937;Leukopenia
938;Leukoplakia
939;Leukoplakia oral
940;Leukorrhea
941;Lichen planus
942;Bullous lichen planus
943;Lichenification
944;Lipodystrophy
945;Lipidoses
946;Lipoma
947;Lipomatosis
948;Listeriosis
949;Liver abscess
950;Cirrhosis liver
951;Alcoholic cirrhosis of liver
952;Unspecified disorder of liver
953;Liver neoplasm
954;Long QT syndrome
955;Lordosis
956;Low back pain
957;Birth weight low
958;Lower gastrointestinal hemorrhage
959;Breast mass
960;Lung abscess
961;Lung disease
962;Chronic obstructive airways disease
963;Lung neoplasm NOS
964;Cutaneous lupus erythematosus
965;Discoid lupus erythematosus
966;Systemic lupus erythematosus
967;Lyme disease
968;Lymphadenitis
969;Lymphangitis
970;Lymphatic disorder
971;Lymphedema
972;Lymphocele
973;Lymphocytosis
974;Hemophagocytic lymphohistiocytosis
975;Lymphoma
976;Non-Hodgkin's lymphoma
977;Lymphopenia
978;Lymphoproliferative disorder
979;Macular degeneration
980;Cystoid macular edema
981;Macular hole
982;Syndrome malabsorption
983;Malaise and fatigue
984;Malaria
985;Mallory-Weiss syndrome
986;Paroxysmal nocturnal hemoglobinuria
987;Mastitis
988;Mastocytosis
989;Mastodynia
990;Mastoiditis
991;Measles
992;Mediastinal disorder
993;Mediastinal emphysema
994;Mediastinal neoplasm NOS
995;Mediastinitis
996;Megacolon
997;Megacolon toxic
998;Melancholia
999;Melanoma
1000;Melanosis
1001;Chloasma
1002;Melena
1003;Menarche
1004;Meniere's disease
1005;Meningioma
1006;Meningism
1007;Meningitis
1008;Meningitis aseptic
1009;Viral meningitis
1010;Meningoencephalitis
1011;Meningomyelocele
1012;Menopausal disorder
1013;Menopause
1014;Menopause premature
1015;Menorrhagia
1016;Menstrual disorder
1017;Retardation mental
1018;Mesothelioma
1019;Unspecified disorder of metabolism
1020;Metaplasia
1021;Methemoglobinemia
1022;Metrorrhagia
1023;Microcephaly
1024;Miliaria
1025;Miosis (persistent), not due to miotics
1026;Diseases of mitral valve
1027;Mitral insufficiency
1028;Mixed connective tissue disease
1029;Molluscum contagiosum
1030;Motion sickness
1031;Congenital mouth malformation NOS
1032;Oral disorder
1033;Neoplasm mouth
1034;Movement disorder
1035;Mucormycosis
1036;Multiparous
1037;Multiple myeloma
1038;Multiple organ failure
1039;Sclerosis multiple
1040;Cramp muscle
1041;Muscle tone flaccid
1042;Hypertonia
1043;Hypotonia
1044;Muscle relaxation
1045;Rigidity muscle
1046;Spasticity muscle
1047;Muscle atrophy
1048;Myopathy
1049;Musculoskeletal disorder
1050;Musculoskeletal pain
1051;Mutism
1052;Myasthenia gravis
1053;Mycobacterium avium intracellulare infection
1054;Unspecified diseases due to mycobacteria
1055;Atypical mycobacterial infection
1056;Mycosis
1057;Mycosis fungoides
1058;Mydriasis
1059;Myelitis
1060;Myelitis transverse
1061;Myelodysplasia
1062;Myelodysplastic syndromes
1063;Myelofibrosis
1064;Myeloproliferative disorder
1065;Myocardial infarction
1066;Myocarditis
1067;Myoclonus
1068;Myofascial pain syndrome
1069;Myoglobinuria
1070;Myopia
1071;Myositis
1072;Myotonia
1073;Myringitis
1074;Myxedema
1075;Diseases of nail
1076;Ingrowing nail
1077;Narcolepsy
1078;Nose congestion
1079;Nasal obstruction
1080;Polyps nasal
1081;Nasopharyngeal disorder
1082;Nasopharyngitis
1083;Nausea
1084;Neck injury
1085;Necrosis
1086;Avascular necrosis of bone
1087;Neonatal abstinence syndrome
1088;Metastasis
1089;Neoplasm
1090;Nephritis
1091;Nephritis interstitial
1092;Nephrocalcinosis
1093;Nephrosclerosis
1094;Nephrosis
1095;Lipoid nephrosis
1096;Syndrome nephrotic
1097;Disorder nervous system
1098;Nervousness
1099;Neural tube defect
1100;Neuralgia
1101;Neuritis
1102;Neurodermatitis
1103;Neurofibroma
1104;Neuroleptic malignant syndrome
1105;Neuroma
1106;Myoneural disorders
1107;Neurotic disorders
1108;Neutropenia
1109;Nevus
1110;Melanocytic nevus
1111;Nicotine dependence
1112;Blindness night
1113;Night sweats
1114;Nightmares
1115;NPN increased
1116;Nocardia infections
1117;Nodule
1118;Nasal disorder NOS
1119;Numbness
1120;Nocturia
1121;Nystagmus
1122;Obesity
1123;Obsessive-compulsive disorder
1124;Obstruction
1125;Occupational exposures
1126;Ochronosis
1127;Hypertension ocular
1128;Hypotony of eye
1129;Unspecified disorder of eye movements
1130;Oculomotor nerve paralysis
1131;Oligomenorrhea
1132;Oligospermia
1133;Oliguria
1134;Ophthalmoplegia
1135;Opioid abuse
1136;Opportunistic infection
1137;Opportunistic mycosis
1138;Atrophy optic
1139;Optic nerve disorder
1140;Neuritis optic
1141;Hemorrhage oral
1142;Orchitis
1143;Organic brain syndrome
1144;Orgasm abnormal
1145;Ectopic ossification
1146;Osteitis
1147;Osteitis fibrosa cystica
1148;Osteoarthritis
1149;Osteochondrosis
1150;Osteogenesis imperfecta
1151;Osteomalacia
1152;Osteomyelitis
1153;Bone necrosis
1154;Osteopenia
1155;Osteoporosis
1156;Osteosarcoma
1157;Osteosclerosis
1158;Other acne
1159;Other conjunctivitis
1160;Other dermatoses
1161;Other scleritis
1162;Otitis
1163;Otitis externa
1164;Otitis media
1165;Secretory otitis media
1166;Ovarian carcinoma
1167;Ovarian cyst
1168;Ovarian disorder
1169;Pain
1170;Pain in limb
1171;Intractable pain
1172;Postoperative pain
1173;Pallor
1174;Palpitations
1175;Disorder pancreas
1176;Insufficiency pancreatic
1177;Pancreatic neoplasm
1178;Pancreatic pseudocyst
1179;Pancreatitis
1180;Pancytopenia
1181;Panic reaction
1182;Panic disorder
1183;Panniculitis
1184;Panuveitis
1185;Papilledema
1186;Papilloma
1187;Paracoccidioidomycosis
1188;Ileus paralytic
1189;Sinus disorder
1190;Paraplegia
1191;Paraproteinemia
1192;Parasomnia
1193;Unspecified disorder of parathyroid gland
1194;Parathyroid tumour
1195;Paresis
1196;Paresthesia
1197;Parkinson's disease
1198;Secondary parkinsonism
1199;Paronychia
1200;Parotitis
1201;Paroxysmal atrial tachycardia
1202;Paroxysmal ventricular tachycardia
1203;Pars planitis
1204;Pathological gambling
1205;Hepatis peliosis
1206;Pellagra
1207;Pelvic abscess
1208;Pelvic infection
1209;Pelvic neoplasm NOS
1210;Pain pelvic
1211;Bullous pemphigoid
1212;Pemphigus
1213;Penicillin allergy
1214;Penis disorder
1215;Peyronie's disease
1216;Ulcer peptic
1217;Peptic ulcer hemorrhage
1218;Peptic ulcer perforation
1219;Perceptual distortions
1220;Dentoalveolar abscess
1221;Polyarteritis nodosa
1222;Periarthritis
1223;Pericardial effusion
1224;Pericarditis
1225;Constrictive pericarditis
1226;Abscess periodontal
1227;Periodontal disease
1228;Periodontitis
1229;Periostitis
1230;Neuropathy peripheral
1231;Vermiculation
1232;Peritonitis
1233;Abscess peritonsillar
1234;Persistent fetal circulation
1235;Personality disorders
1236;Petechiae
1237;Phantom limb (syndrome)
1238;Unspecified disease of pharynx
1239;Pharyngitis
1240;Phenylketonuria
1241;Tight foreskin
1242;Phlebitis
1243;Phocomelia
1244;Polymorphic light eruption
1245;Pica
1246;Piloerection
1247;Pilonidal cyst
1248;Pituitary adenoma
1249;Pituitary apoplexy
1250;Pituitary neoplasms
1251;Placental disorder
1252;Pleural disorder
1253;Effusion pleural
1254;Pleural rub
1255;Pleurisy
1256;Pneumatosis cystoides intestinalis
1257;Pneumonia
1258;Pneumonia aspiration
1259;Pneumonia lobar
1260;Pneumonia mycoplasmal
1261;Pneumopericardium
1262;Pneumoperitoneum
1263;Pneumothorax
1264;Poliomyelitis
1265;Polycystic ovaries
1266;Polycythemia
1267;Polycythemia vera
1268;Polymenorrhea
1269;Genetic polymorphism
1270;Polymyalgia rheumatica
1271;Polyneuritis
1272;Polyps
1273;Polyuria
1274;Dyshidrosis
1275;Disorders of porphyrin metabolism
1276;Tuberculin test positive
1277;PHN
1278;Postnasal drip
1279;Postoperative complications NOS
1280;Postoperative hemorrhage
1281;Hemorrhage postpartum
1282;Potassium deficiency
1283;Pre-eclampsia
1284;Pregnancy
1285;Complications of pregnancy NOS
1286;Pregnancy ectopic
1287;Pregnancy multiple
1288;Tubal pregnancy
1289;Premature beat atrial
1290;Ejaculation premature
1291;Premenstrual syndrome
1292;Presbyopia
1293;Priapism
1294;Proctitis
1295;Proctocolitis
1296;Prolactinoma
1297;Prostatic disorder
1298;Prostatic neoplasm NOS
1299;Prostatitis
1300;Proteinuria
1301;Prurigo
1302;Pruritus
1303;Pruritus ani
1304;Pruritus genital
1305;Pruritus vulvae
1306;Pseudodementia
1307;Pseudomonas infection
1308;Pseudotumor
1309;Pseudotumor cerebri
1310;Psoriasis
1311;Headache tension
1312;Psychosomatic disease
1313;Alcoholic psychoses
1314;Female orgasmic disorder
1315;Male orgasmic disorder
1316;Psychosexual disorder
1317;Psychotic disorder NOS
1318;Pterygium
1319;Puberty
1320;Delayed puberty
1321;Puberty precocious
1322;Postpartum disorder
1323;Pulmonary alveolar proteinosis
1324;Edema pulmonary
1325;Embolism pulmonary
1326;Emphysema pulmonary
1327;Pulmonary eosinophilia
1328;Fibrosis pulmonary
1329;Cor pulmonale
1330;Pulmonary infarction
1331;Lung nodule
1332;Pulmonary valve insufficiency
1333;Pulmonary veno-occlusive disease
1334;Pulpitis
1335;Pupil disorders
1336;Purpura
1337;Schoenlein-Henoch purpura
1338;Thrombotic thrombocytopenic purpura
1339;Pyelitis
1340;Pyelonephritis
1341;Stenosis pyloric
1342;Pyoderma
1343;Pyometra
1344;Pyuria
1345;Quadriplegia
1346;Radiation injury
1347;Radiculitis
1348;Dermatitis radiation NOS
1349;Radius fracture
1350;Rage
1351;Rales
1352;Raynaud's disease
1353;Hyperacusis
1354;Rectal disorder
1355;Rectal fistula
1356;Rectal pain
1357;Rectal polyp
1358;Rectal prolapse
1359;Aplasia pure red cell
1360;Reflex sympathetic dystrophy
1361;Abnormal reflex
1362;Babinski sign positive
1363;Refractive errors NOS
1364;Relapsing fever
1365;Renal artery stenosis
1366;Failure kidney
1367;Renal infarct
1368;Reperfusion injury
1369;Repetitive strain injury
1370;Adult respiratory distress syndrome
1371;Respiratory insufficiency
1372;Respiratory paralysis
1373;Respiratory syncytial virus infection
1374;Respiratory tract infections
1375;Syndrome restless legs
1376;Reticuloendotheliosis
1377;Occlusion retinal artery
1378;Degeneration retinal
1379;Detachment retinal
1380;Retinal disorder
1381;Hemorrhage retinal
1382;Retinal break
1383;Retinal vascular occlusion
1384;Occlusion retinal vein
1385;Retinitis
1386;Retinopathy of prematurity
1387;Retroperitoneal fibrosis
1388;Reye's syndrome
1389;Rhabdomyolysis
1390;Rheumatism
1391;Rhinitis
1392;Perennial allergic rhinitis
1393;Atrophic rhinitis
1394;Vasomotor rhinitis
1395;Rhonchi
1396;Rib fracture
1397;Rickets
1398;Rosacea
1399;Diseases of the salivary glands
1400;Salivation
1401;Gastroenteritis salmonella
1402;Salmonella infections
1403;Salpingitis
1404;Sarcoidosis
1405;Cutaneous sarcoidosis
1406;Kaposi's sarcoma
1407;Schizoaffective disorder
1408;Schizophrenia
1409;Sciatica
1410;Scleral disorder
1411;Scleritis
1412;Circumscribed scleroderma
1413;Scoliosis
1414;Scotoma
1415;Diseases of sebaceous glands
1416;Seborrheic dermatitis
1417;Cardiomyopathy secondary NOS
1418;Seizures
1419;Self mutilation
1420;Separation
1421;Pharyngitis streptococcal
1422;Septicemia
1423;Serositis
1424;Serum sickness
1425;TIBC
1426;Sexual desire disorders
1427;Sexually transmitted disease
1428;Shivering
1429;Shock
1430;Cardiogenic shock
1431;Hemorrhagic shock
1432;Shock septic
1433;Shoulder pain
1434;Sialadenitis
1435;Sialorrhea
1436;Syndrome sick sinus
1437;Gastrointestinal signs and symptoms
1438;Sinoatrial block
1439;Sinus headache
1440;Sinusitis
1441;Congenital skin disorder
1442;Skin disorder
1443;Skin infection
1444;Skin lesion
1445;Neoplasm skin
1446;Skin nodule
1447;Pigmentation skin
1448;Skin tags
1449;Ulcer skin
1450;Skin wrinkling
1451;Sleep apnea syndromes
1452;Sleep disturbances
1453;Night terrors
1454;Sneezing
1455;Snoring
1456;Soft tissue injury
1457;Somatoform disorder
1458;Somnambulism
1459;Spasms
1460;Spastic paraparesis
1461;Disorder speech
1462;Spermatocele
1463;Spinal cord compression
1464;Unspecified disease of spinal cord
1465;Spinal cord injury
1466;Spinal disorder
1467;Spleen disorder
1468;Splenic infarction
1469;Splenic rupture
1470;Splenomegaly
1471;Spondylitis
1472;Ankylosing spondylitis
1473;Spondylosis
1474;Sprain
1475;Staphylococcal infections
1476;Staphylococcal scalded skin syndrome
1477;Staphylococcal skin infection
1478;Status asthmaticus
1479;Status epilepticus
1480;Steatorrhea
1481;Stereotypic movement disorder
1482;Stevens-Johnson syndrome
1483;Gastric dilatation
1484;Gastropathy
1485;Gastric ulcer
1486;Stomatitis
1487;Stomatitis aphthous
1488;Ulcerative stomatitis
1489;Strabismus
1490;Streptococcal infections
1491;Stress
1492;Stridor
1493;Cerebrovascular accident
1494;Strongyloidiasis
1495;Stuttering
1496;Hemorrhage subarachnoid
1497;Subconjunctival hemorrhage
1498;Subdural effusion
1499;Withdrawal syndrome
1500;Sudden infant death syndrome
1501;Suicide
1502;Suicide attempt
1503;Sulfhemoglobinemia
1504;Sunburn
1505;Superinfection
1506;Superior vena cava syndrome
1507;Surgical wound infection
1508;Unspecified disorder of sweat glands
1509;Sweat gland tumour
1510;Sweating
1511;Swelling
1512;Syncope
1513;Syndactyly
1514;Synovitis
1515;Syphilis
1516;Tachycardia
1517;Junctional tachycardia
1518;Tachycardia sinus
1519;Supraventricular tachycardia
1520;Tachyphylaxis
1521;Taste disorders
1522;Telangiectasis
1523;Temporomandibular joint syndrome
1524;Tendinitis
1525;Tendon injury
1526;Tenosynovitis
1527;Testis disorder
1528;Pain in testis
1529;Tetany
1530;Tetralogy of Fallot
1531;Thirst
1532;Essential thrombocythemia
1533;Thrombocytopenia
1534;Thromboembolism
1535;Thrombophlebitis
1536;Thrombosis
1537;Crisis thyroid
1538;Unspecified disorder of thyroid
1539;Neoplasm thyroid
1540;Thyroid nodule
1541;Thyroiditis
1542;Thyrotoxicosis
1543;VT
1544;Tietze's syndrome
1545;Tinea
1546;Tinea corporis
1547;Tinea pedis
1548;Onychomycosis
1549;Tinea versicolor
1550;Tinnitus
1551;Unspecified condition of the tongue
1552;Tongue neoplasm NOS
1553;Tongue hairy
1554;Tonsillitis
1555;Tooth malformation
1556;Discoloration tooth
1557;Tooth disorder
1558;Tooth erosion
1559;Tooth fracture
1560;Toothache
1561;Torsades de pointes
1562;Torticollis
1563;Gilles de la Tourette syndrome
1564;Toxoplasmosis
1565;Tracheal disorder
1566;Tracheitis
1567;Tracheobronchitis
1568;Tracheoesophageal fistula
1569;Traumatic haemorrhage
1570;Tremor
1571;Treponema infections
1572;Trichomonal vaginitis
1573;Trichotillomania
1574;Tricuspid insufficiency
1575;Neuralgia trigeminal
1576;Trismus
1577;Tuberculosis
1578;Tubulointerstitial nephritis
1579;Tumor lysis syndrome
1580;Turner's syndrome
1581;Conjoined twins
1582;Typhoid fever
1583;Ulcer
1584;Ulna fracture
1585;Loss of consciousness
1586;Underweight
1587;Attention deficit disorder
1588;Unintended pregnancy
1589;Deficiency anaemia
1590;Tympanic membrane disorder
1591;Erythema
1592;Upper gastrointestinal hemorrhage
1593;Upper respiratory infection
1594;Uremia
1595;Ureter obstruction
1596;Ureteritis
1597;Urethral disorder
1598;Urethral obstruction
1599;Urethral stricture
1600;Urethritis
1601;Uric acid level increased
1602;Micturition frequency increased
1603;Incontinence urinary
1604;Urinary tract infection
1605;Micturition disorder
1606;Urogenital anomaly NOS
1607;Neoplasm urogenital
1608;Unspecified disorder of urethra and urinary tract
1609;Urticaria
1610;Uterine contractions
1611;Uterine disorder
1612;Uterine fibroids
1613;Uterine hemorrhage
1614;Atony uterine
1615;Uterine neoplasms
1616;Perforation uterine
1617;Uterine prolapse
1618;Uterine rupture
1619;Uveitis
1620;Anterior uveitis
1621;Posterior uveitis
1622;Vogt-Koyanagi-Harada syndrome
1623;Vaginal disorder
1624;Vaginal itching
1625;Vaginal neoplasm NOS
1626;Vaginitis
1627;Varicocele
1628;Varicosity
1629;Vascular disorders
1630;Headache vascular
1631;Vascular resistance
1632;Vasculitis
1633;Vasodilation
1634;Syncope vasovagal
1635;Venous insufficiency
1636;Thrombosis venous
1637;Fibrillation ventricular
1638;Ventricular tachycardia
1639;Plantar warts
1640;Vertebrobasilar insufficiency
1641;Vertigo
1642;Vestibular disorder
1643;Viral hepatitis
1644;Viral syndrome
1645;Viremia
1646;Virilism
1647;Viral infection
1648;Vision disorders
1649;Vision decreased
1650;Cobalamin deficiency
1651;Unspecified vitamin B deficiency
1652;Vitamin K deficiency
1653;Vitiligo
1654;Vitreous detachment
1655;Vitreous hemorrhage
1656;Paralysis vocal cord
1657;Volvulus
1658;Vomiting
1659;Disorder vulva
1660;Vulvitis
1661;Vulvovaginitis
1662;Wakefulness
1663;Common wart
1664;Wasting generalized
1665;Water intoxication
1666;Wegener's granulomatosis
1667;Weight gain
1668;Weight loss
1669;Idiopathic thrombocytopenic purpura
1670;Wheezing
1671;Whiplash injury
1672;Pertussis
1673;Wound infection
1674;Laceration
1675;Wound
1676;Trauma
1677;Xanthomatosis
1678;Xeroderma
1679;Xerophthalmia
1680;Xerostomia
1681;Yawning
1682;Zollinger-Ellison syndrome
1683;HIV associated nephropathy
1684;Intraoperative hemorrhage
1685;Bradyarrhythmia
1686;Bronchoconstriction
1687;Thrombosis cerebral
1688;Helicobacter infections
1689;B-cell lymphoma
1690;Diffuse large B-cell lymphoma
1691;T-cell lymphoma
1692;Cutaneous T-cell lymphoma
1693;Oligohydramnios
1694;Spina bifida occulta
1695;Spina bifida
1696;Spinal fractures
1697;Muscle strain
1698;Tachyarrhythmia
1699;Tooth loss
1700;Retention urinary
1701;Urogenital disorder
1702;Granuloma annulare
1703;Sweet syndrome
1704;Fungemia
1705;Ovarian hyperstimulation syndrome
1706;Motor neuron disease
1707;Peripheral vascular disease
1708;Ulcer foot
1709;Cardiac output increased
1710;Bronchial hyperreactivity
1711;Central nervous system neoplasm
1712;Hidradenitis
1713;Vaginosis bacterial
1714;Gestational diabetes
1715;Self injurious behavior
1716;Erythema infectiosum
1717;Sudden cardiac death
1718;Hypocapnia
1719;Immunocompromised
1720;Gram-negative bacterial infection NOS
1721;Cryptococcal meningitis
1722;Bacterial meningitis
1723;Acidosis hyperchloraemic
1724;Hypokalemic alkalosis
1725;Microcytic anaemia
1726;Normocytic anemia
1727;Essential hypertension
1728;Neuritis retrobulbar
1729;Choreoathetosis
1730;Encephalopathies
1731;Chills
1732;Fever chills
1733;Body odor
1734;Polydipsia
1735;Failure liver
1736;Micturition urgency
1737;Sinus bradycardia
1738;Atrial arrhythmia
1739;Ventricular arrhythmia
1740;First degree atrioventricular block
1741;Right bundle branch block
1742;Vasospasm
1743;Arterial spasm
1744;Venospasm
1745;Orthopnea
1746;Paralysis flaccid
1747;Spastic paralysis
1748;Monoplegia
1749;Akinesia
1750;Burning sensation
1751;Hypoalgesia
1752;Stupor
1753;Agitation
1754;Apathy
1755;Mood swings
1756;Photopsia
1757;Photophobia
1758;Oculogyric crisis
1759;Fall
1760;Pustular rash
1761;Livedo reticularis
1762;Synovial cyst
1763;Peripheral edema
1764;Purpura fulminans
1765;Pyoderma gangrenosum
1766;Pyogenic granuloma
1767;Injection site granuloma
1768;Polymyositis
1769;Aseptic necrosis
1770;Onycholysis
1771;Acute leukemia
1772;Hyperchloraemia
1773;Hypochloraemia
1774;Hyperphosphatemia
1775;Hypophosphatemia
1776;Footdrop
1777;Breast engorgement
1778;Cystitis haemorrhagic
1779;Acute appendicitis
1780;Cholecystitis chronic
1781;Pyelonephritis chronic
1782;Monocytosis
1783;Mendelson's syndrome
1784;Alcohol abuse
1785;Hamman-Rich syndrome
1786;Antibiotic associated colitis
1787;Bullous dermatoses
1788;Coryza
1789;Depressive symptom
1790;Dissociation
1791;Enterobiasis
1792;Hypogammaglobulinemia
1793;Hypokinesia
1794;Lassitude
1795;Cataract
1796;Hepatic dysfunction NOS
1797;Benign neoplasm
1798;Panic attacks
1799;Syndrome sicca
1800;Withdrawal symptom
1801;Toxic encephalopathy
1802;Acute sinusitis
1803;Acute bronchitis
1804;Chronic sinusitis
1805;Acute gastritis
1806;Acute cholecystitis
1807;Chronic pancreatitis
1808;Acute cystitis
1809;Allergic urticaria
1810;Fracture of pelvis
1811;Cervical adenitis
1812;Clubbing
1813;Epstein-Barr virus infection
1814;Gingivostomatitis
1815;Hemospermia
1816;Hepatitis B surface antigen positive
1817;Left ventricular hypertrophy
1818;Lower respiratory tract infection
1819;Pulmonary mass
1820;Muscle rupture
1821;Nipple discharge
1822;Oral lesion
1823;Mouth ulceration
1824;Plantar fasciitis
1825;Purpura senile
1826;Rectal abscess
1827;Rectocele
1828;Abscesses of skin
1829;Soft tissue infection NOS
1830;Squamous cell carcinoma of lung
1831;Amaurosis fugax
1832;Urosepsis
1833;Chemical conjunctivitis
1834;Deep vein thrombosis
1835;Epididymo-orchitis
1836;Slipped femoral capital epiphysis
1837;Parulis
1838;Hepatitis cholestatic
1839;Hypercalcaemia of malignancy
1840;Small cell carcinoma of the lung
1841;Migraine
1842;Acute interstitial nephritis
1843;Torsion of ovary
1844;Complex partial seizures
1845;Proctitis herpes
1846;Secondary syphilis
1847;Urge incontinence
1848;Chronic pain
1849;Skin breakdown
1850;Altered state of consciousness
1851;Palpable purpura
1852;Periorbital oedema
1853;Genital ulceration
1854;Paresthesia generalized
1855;Cranial nerve paralysis
1856;Sensory neuropathy
1857;Neck stiffness
1858;Allergic cutaneous angiitis
1859;Breast abscess
1860;Injection site abscess
1861;Renal abscess
1862;Addisonian crisis
1863;Adenoma thyroid
1864;Albumin globulin ratio abnormal
1865;Alcohol intolerance
1866;Alkalosis hypochloraemic
1867;Hormone level abnormal
1868;Neurotransmitter level altered
1869;Amylase increased
1870;Antinuclear antibody positive
1871;Arterial anomaly
1872;Congenital central nervous system anomaly
1873;Anomaly congenital musculoskeletal (NOS)
1874;Syndrome anticholinergic
1875;Application site reaction
1876;Adrenal cortex atrophy
1877;Atrophy of breast
1878;Injection site atrophy
1879;Skin atrophy
1880;Atrioventricular block, complete
1881;Birth premature
1882;Bleeding time prolonged
1883;Bronchostenosis
1884;Buccoglossal syndrome
1885;Blood urea increased
1886;Capillary fragility increased
1887;Gastrointestinal carcinoma
1888;Cataract specified
1889;Cinchonism
1890;CNS depression NOS
1891;Coagulation time prolonged
1892;Rigidity cogwheel
1893;Hemorrhagic colitis
1894;Coombs direct test positive
1895;Corneal lesion
1896;Cough decreased
1897;Creatine phosphokinase increased
1898;Creatinine renal clearance decreased
1899;Creatinine increased
1900;Crystalluria
1901;Crystalluria calcium
1902;Urate crystalluria
1903;Injection site cyst
1904;Deafness permanent
1905;Partial permanent deafness
1906;Transitory deafness
1907;Partial transitory deafness
1908;Diarrhoea haemorrhagic
1909;Digitalis intoxication (NOS)
1910;Tongue discolouration
1911;Drug level decreased
1912;Drug level increased
1913;Conjunctival oedema
1914;Swelling face
1915;Anasarca
1916;Oedema genital
1917;Injection site swelling
1918;Oedema labial genital
1919;Scrotal oedema
1920;Tongue oedema
1921;Electroencephalogram abnormal
1922;Electrolyte abnormality
1923;Electrolyte depletion
1924;Embolus leg
1925;Encephalopathy hypertensive
1926;Endometrial disorder
1927;Enterocolitis haemorrhagic
1928;Ulcerative enterocolitis
1929;Enzyme abnormality
1930;Necrolysis epidermal
1931;Epiphyses premature fusion
1932;Fixed eruption
1933;Red blood cell sedimentation rate increased
1934;Premature ventricular contractions
1935;Syndrome Fanconi-like
1936;Fertility female decreased
1937;Fertility male decreased
1938;Injection site fibrosis
1939;Kidney fibrosis
1940;Peripheral gangrene
1941;Gamma-glutamyltransferase increased
1942;Gastrointestinal perforation
1943;Globulins decreased
1944;Gammaglobulins decreased
1945;Gamma globulins increased
1946;Glucose tolerance decreased
1947;Gonadotropins NOS low
1948;Gonadotropic luteinizing hormone increased
1949;Neutrophils increased
1950;Granuloma skin
1951;Growth accelerated
1952;Growth retardation
1953;Hair discoloration
1954;High density lipoprotein decreased
1955;Impaired healing
1956;Adrenal haemorrhage
1957;Hemorrhage of colon
1958;Injection site hemorrhage
1959;Intracranial haemorrhage NOS
1960;Pulmonary hemorrhage
1961;Muscle hemorrhage
1962;Retroperitoneal haemorrhage
1963;Hyperchlorhydria
1964;Hypermagnesemia
1965;Skin hypertrophy
1966;Hypocholesterolemia
1967;Testicular hypogonadism
1968;Hypomagnesaemia
1969;Injection site hypersensitivity
1970;Immunoglobulins decreased
1971;Immunoglobulins increased
1972;Drug effect increased
1973;Injection site inflammation
1974;Injection site reaction
1975;Accidental injury
1976;Intentional injury
1977;Large intestine perforation
1978;Perforation small intestine
1979;Hypertension intracranial
1980;Ischemia myocardial
1981;Kidney function abnormal
1982;Renal tubular disorder
1983;Lactation female
1984;Lactic dehydrogenase activity increased
1985;Lenticular pigmentation
1986;Liver damage
1987;Liver fatty deposition
1988;Liver function test abnormal
1989;Liver tenderness
1990;Manic psychosis
1991;Bone marrow depression
1992;Injection site mass
1993;Melanoma skin
1994;Mucous membrane disorder
1995;Weakness muscle
1996;Eosinophilic myocarditis
1997;Nasal septum disorder
1998;Injection site necrosis
1999;Hepatic necrosis
2000;Skin necrosis
2001;Lack of drug effect
2002;Subcutaneous nodule
2003;Occlusion coronary
2004;Mesenteric occlusion
2005;Opisthotonus
2006;Accidental overdose
2007;Colic biliary
2008;Bone pain
2009;Retrosternal pain
2010;Eye pain
2011;Injection site pain
2012;Urethral pain
2013;Papanicolau smear suspicious
2014;Paranoid reaction
2015;Circumoral paresthesia
2016;Disorder periosteal
2017;Acid phosphatase high
2018;Phosphatase alkaline increased
2019;Abnormal platelets
2020;Polyserositis
2021;Pregnancy disorder
2022;Pregnancy test false positive
2023;Prothrombin level increased
2024;Electrocardiogram QT prolonged
2025;Electrocardiogram QT shortened
2026;Purpuric rash
2027;Vesiculobullous rash
2028;Reaction aggravation
2029;Hyporeflexia
2030;Hyperreflexia
2031;Retinal depigmentation
2032;Retinal pigmentation
2033;Schizophrenic reaction
2034;Syndrome screaming
2035;Serum iron increased
2036;Aspartate aminotransferase increased
2037;Alanine aminotransferase increased
2038;Discoloration skin
2039;Dry skin
2040;Generalised spasm
2041;Bladder stenosis
2042;Hypogeusia
2043;Tendon disorder
2044;Tendon rupture
2045;Hypocalcemic tetany
2046;Arterial thrombosis
2047;Cerebral venous thrombosis
2048;Pulmonary thrombosis
2049;Thromboplastin decreased
2050;Decreased tolerance
2051;Conjunctival ulcer
2052;Duodenal ulcer haemorrhage
2053;Ulcer of esophagus
2054;Intestinal ulcer
2055;Small intestine ulcer
2056;Peptic ulcer reactivated
2057;Uterus enlarged
2058;Degeneration of uterine fibroid
2059;Uterine fibroids enlarged
2060;Uterine spasm
2061;Renal vasculitis
2062;Vitreous opacities
2063;Vulvovaginal disorder
2064;WBC abnormal NOS
2065;Withdrawal bleed
2066;Esophageal carcinoma
2067;Gastroparesis
2068;Heart disease congenital
2069;Polyneuropathy
2070;Sensory disturbance
2071;Sinus congestion
2072;Skin irritation
2073;Joint swelling
2074;Urinary hesitation
2075;Streptobacillary fever
2076;Pustular psoriasis
2077;Traumatic arthropathy
2078;Edwards' syndrome
2079;Orofacial dyskinesia
2080;Drug withdrawal syndrome
2081;Mittelschmerz
2082;Prolonged labor
2083;Persistent vomiting
2084;Anal spasm
2085;Spasm of sphincter of Oddi
2086;Colic renal
2087;Primary pulmonary hypertension
2088;Ventricular flutter
2089;Explosive personality disorder
2090;Central scotoma
2091;Scotoma of blind spot area
2092;Spasm of accommodation
2093;Accommodation disorder
2094;Acquired night blindness
2095;Cyclophoria
2096;Epiphora
2097;Posterior synechiae of iris
2098;Polydactyly
2099;Imperforate hymen
2100;Urethral discharge
2101;Skin striae
2102;Salmonella sepsis
2103;Viral diarrhoea
2104;Disseminated tuberculosis
2105;Streptococcal sepsis
2106;Staphylococcal bacteraemia
2107;Pseudomonal sepsis
2108;Respiratory moniliasis
2109;Systemic candidiasis
2110;Malignant neoplasm of gallbladder
2111;Uterine cancer
2112;Malignant neoplasm of renal pelvis
2113;Malignant neoplasm of ureter
2114;Lung cancer metastatic
2115;Bone cancer metastatic
2116;Benign neoplasm of vagina
2117;Benign neoplasm of parathyroid gland
2118;Lipid metabolism disorders
2119;Myopathy toxic
2120;Serous retinal detachment
2121;Retinal vascular disorder
2122;Central retinal vein occlusion
2123;Iris adhesions
2124;Acute angle-closure glaucoma
2125;Cataract traumatic
2126;Subjective visual disturbances
2127;Sudden visual loss
2128;Transient blindness
2129;Bullous keratopathy
2130;Corneal degeneration
2131;Chronic conjunctivitis
2132;Ocular hyperemia
2133;Conjunctival cyst
2134;Eczematous dermatitis of eyelid
2135;Eyelid bleeding
2136;Ischemic optic neuropathy
2137;Cortical blindness
2138;Vitreous disorder
2139;Vitreous prolapse
2140;External ear disorder
2141;Otosalpingitis
2142;Vertigo central nervous system origin
2143;Otorrhoea
2144;Neural hearing loss
2145;Secondary hypertension
2146;Acute myocardial infarction
2147;Atrial fibrillation and flutter
2148;Papillary muscle rupture
2149;Disease of capillaries
2150;Portal vein thrombosis
2151;Bleeding esophageal varices
2152;Varicose veins vulval
2153;Pneumonia streptococcal
2154;Pulmonary anthrax
2155;Allergic asthma
2156;Acute pulmonary oedema
2157;Arthralgia of temporomandibular joint
2158;Dentofacial anomaly
2159;Atrophic glossitis
2160;Bladder diverticulum
2161;Urethral syndrome
2162;Penile oedema
2163;Testicular atrophy
2164;Breast fibrosis
2165;Vulval ulceration
2166;Uterovaginal prolapse
2167;Uterine polyp
2168;Vaginal dysplasia
2169;Enlarged clitoris
2170;Menstruation irregular
2171;Unspecified abortion
2172;Abnormalities of the hair
2173;Monarthritis
2174;Intervertebral disc disorder
2175;Intervertebral disc degeneration
2176;Calcaneal spur
2177;Trigger finger
2178;Tendinous contracture
2179;Infective myositis
2180;Swelling of limb
2181;Vascular anomaly
2182;Congenital genital malformation
2183;Spine malformation
2184;Hypoglycaemia neonatal
2185;Convulsion neonatal
2186;General symptom
2187;Spontaneous bruising
2188;Abnormal chest sounds NOS
2189;Abnormal bowel sounds
2190;Abdominal rigidity
2191;Choluria
2192;Facial bones fracture
2193;Fracture of clavicle
2194;Fracture of ankle
2195;Ankle sprain
2196;Liver injury
2197;Brachial plexus injury
2198;Nerve injury
2199;Haemoglobin decreased
2200;Ketonuria
2201;Choroidal detachment
2202;Corneal deposits
2203;Diabetes insipidus nephrogenic
2204;Edema of eyelid
2205;Abnormal faeces
2206;Retinal ischaemia
2207;External ophthalmoplegia
2208;Polyarthralgia
2209;Respiratory arrest
2210;Joint stiffness
2211;Androgenetic alopecia
2212;Iron deficiency anemia
2213;Polyarthritis
2214;Femur fracture subtrochanteric
2215;Miliaria rubra
2216;Malnutrition
2217;Ischemic colitis
2218;Variegate porphyria
2219;Porphyria hepatic
2220;Acute liver failure
2221;Acute intermittent porphyria
2222;Porphyria cutanea tarda
2223;Skin bacterial infection
2224;Viral skin infection
2225;Apoptosis
2226;Neurofibromatosis
2227;HELLP syndrome
2228;Hypertrophic scar
2229;Allergic contact dermatitis
2230;Dermatitis irritant contact
2231;Photocontact dermatitis
2232;Photosensitivity reaction
2233;Skin hyperpigmentation
2234;Hypopigmentation disorders
2235;Eruption lichenoid
2236;Pityriasis lichenoides et varioliformis acuta
2237;Abdominal aortic aneurysm
2238;Acneiform eruption
2239;Citrullinemia
2240;Corpus callosum agenesis
2241;Intestinal infections
2242;Abdominal hernia
2243;Skin and subcutaneous tissue disorders
2244;Upper limb fracture
2245;Prostatic specific antigen increased
2246;Hypoplastic anemia
2247;Anhedonia
2248;Fibroadenoma of breast
2249;Hypertrophic osteoarthropathy
2250;Reproductive tract disorder
2251;Tumor progression
2252;Urinary tract obstruction
2253;Acute pain
2254;Scab
2255;Sprue
2256;Papillomatosis
2257;Fistula anal
2258;Prolapse vaginal
2259;Interstitial pneumonia
2260;Interstitial lung disease
2261;Radiation pneumonitis
2262;Neuroectodermal neoplasm
2263;Reticulocytosis
2264;Community acquired infection
2265;Cytomegalovirus retinitis
2266;Anaplastic large-cell lymphoma
2267;Fatal outcomes
2268;Tympanic membrane perforation
2269;Hepatoblastoma
2270;Angiomyolipoma
2271;Hepatocellular adenoma
2272;Cholangiocarcinoma
2273;Unspecified congenital anomaly of unspecified limb
2274;Brain metastases
2275;Hyperpnea
2276;Lightheadedness
2277;Metabolic acidosis
2278;Ketoacidosis
2279;Metabolic alkalosis
2280;Hyperammonemia
2281;Primary hyperparathyroidism
2282;Red blood cell disorders
2283;Microangiopathic hemolytic anemia
2284;Hyperviscosity syndrome
2285;Berardinelli-Seip syndrome
2286;Dialysis dementia
2287;Bradycardia-tachycardia syndrome
2288;Anterior spinal artery syndrome
2289;Hangover effect
2290;Platelet production decreased
2291;Odynophagia
2292;Obstipation
2293;Hypertension paroxysmal
2294;Systolic hypertension
2295;Multifocal atrial tachycardia
2296;Shallow breathing
2297;Diplegia
2298;Paraparesis
2299;Muscle stiffness
2300;Xanthopsia
2301;Macular rash
2302;Vesicular rash
2303;Comedone
2304;Welts
2305;Angular cheilitis
2306;Glomerulonephritis rapidly progressive
2307;Fixed drug eruption
2308;Dandruff
2309;Skin fissure
2310;Gouty tophus
2311;Eruptive xanthoma
2312;Calcification metastatic
2313;Nail dystrophy
2314;Cheilosis
2315;Pseudolymphoma
2316;Elastosis perforans
2317;Anisocytosis
2318;Poikilocytosis
2319;Hypouricaemia
2320;Nail discoloration
2321;Yellow nail syndrome
2322;Follicular conjunctivitis
2323;Vaginitis atrophic
2324;Erythropenia
2325;Cushing's disease
2326;Sickness
2327;Melanoderma
2328;Aphagia
2329;Vasomotor collapse
2330;Epigastric distress
2331;Stomach ache
2332;Road traffic accident
2333;Injection site infection
2334;Contact lens intolerance
2335;Muscle movement involuntary
2336;Bronchial obstruction
2337;Oesophageal pain
2338;Paradoxical pressor response
2339;Serum sickness-like reaction
2340;Depression suicidal
2341;Blood urine
2342;Stiff back
2343;Hyperamylasemia
2344;Oral pain
2345;Nontoxic goiter
2346;Rectal discharge
2347;Uterine mass
2348;Ache wrists
2349;Discharge vaginal
2350;Disability
2351;Malaise
2352;Fatigability
2353;Weight gain poor
2354;Body mass index decreased
2355;Heat intolerance
2356;Distress
2357;Urination impaired
2358;Immobile
2359;Joint hyperextension
2360;Posture abnormal
2361;Muscular incoordination
2362;Myalgia
2363;Tendon pain
2364;Muscle twitch
2365;Bone development abnormal
2366;Joint crepitation
2367;Occipital headache
2368;Wrist drop
2369;Unsteady gait
2370;Gait shuffling
2371;Festinating gait
2372;Buttock pain
2373;Knee pain
2374;Burning foot
2375;Carpo-pedal spasm
2376;Dyspnoea exertional
2377;Tachypnea
2378;Respiratory rate decreased
2379;Breath sounds abnormal
2380;Wheezing inspiratory
2381;Wheezing expiratory
2382;Nasal dryness
2383;Volume plasma increased
2384;Venous pressure increased
2385;Skipped beats
2386;Thready pulse
2387;Reflex bradycardia
2388;Cardiac fibrillation
2389;Gallop rhythm
2390;Sinus rhythm
2391;Atrial rhythm
2392;Nodal rhythm
2393;Systolic murmur
2394;Pericardial rub
2395;Chest pressure sensation of
2396;Precordial pain
2397;Chest pain exertional
2398;Chest tightness
2399;Electrocardiogram U wave present
2400;Vascular insufficiency
2401;Hair growth abnormal
2402;Hair growth increased
2403;Cold sweat
2404;Cutis anserina
2405;Digestion impaired
2406;Increased appetite
2407;Appetite decreased NOS
2408;Abdominal discomfort
2409;Abdominal colic
2410;Abdominal pain upper
2411;Epigastric pain
2412;Abdominal pain lower
2413;Abdominal tenderness
2414;Epigastric fullness
2415;Bilious vomiting
2416;Retching
2417;Borborygmi
2418;Bowel sounds decreased
2419;Rectal tenesmus
2420;Asterixis
2421;Function kidney decreased
2422;Shutdown renal
2423;Antidiuresis
2424;Hyposthenuria
2425;Bladder dysfunction
2426;Bladder pain
2427;Penile discharge
2428;Teratogenicity
2429;Menstrual cycle abnormal
2430;Amenorrhea secondary
2431;Menometrorrhagia
2432;Spermatogenesis arrest
2433;Psychiatric symptom
2434;Disorientation
2435;Temporal disorientation
2436;Disturbance in attention
2437;Distractibility
2438;Poor concentration
2439;Emotional disorder
2440;Inappropriate affect
2441;Blunted affect
2442;Flat affect
2443;Affect lability
2444;Dysphoria
2445;Elevated mood
2446;Worry
2447;Apprehension
2448;Feeling of despair
2449;Tension
2450;Abnormal behavior
2451;Suspiciousness
2452;Antisocial behavior
2453;Temper tantrum
2454;Bradykinesia
2455;Physical wandering
2456;Excitement
2457;Thinking disturbances
2458;Bradypsychic response
2459;Perseveration
2460;Flight of ideas
2461;Thought blocking
2462;Obsession
2463;Speech impairment NOS
2464;Pressure of speech
2465;Perceptual disturbance
2466;Derealization
2467;Auditory hallucinations
2468;Visual hallucinations
2469;Hallucination, tactile
2470;Hypnagogic hallucination
2471;Somatic hallucination
2472;Memory impairment
2473;Anterograde amnesia
2474;Amnesia transient
2475;Judgement impaired
2476;Clumsiness
2477;Nocturnal emission
2478;Painful erection
2479;Clitoral engorgement
2480;Anorgasmia
2481;Ejaculation delayed
2482;Motor dysfunction
2483;Extrapyramidal symptoms
2484;Dysgraphia
2485;Absent reflex
2486;Dysmetria
2487;Sensation of cold
2488;Sensation of heat
2489;Pallanesthesia
2490;Discomfort
2491;Pressure
2492;Pain burning
2493;Tenderness
2494;Ache
2495;Trembling
2496;Tremor fine
2497;Tremor coarse
2498;Action tremor
2499;Consciousness abnormal
2500;Abnormal dreams
2501;Anosognosia
2502;Slurred speech
2503;Convulsions generalised
2504;Clonic seizures
2505;Postictal state
2506;Visual acuity reduced
2507;Burning sensation in eye
2508;Periorbital pain
2509;Eyelid retraction
2510;Intraocular pressure increased
2511;Dermatitis acneiform
2512;Nail changes
2513;Rash erythematous
2514;Rash follicular
2515;Rash morbilliform
2516;Rash scaly
2517;Oily skin
2518;Skin odour abnormal
2519;Urticaria vesiculosa
2520;Acute urticaria
2521;Application site oedema
2522;Injection site abscess sterile
2523;Inflammatory swelling
2524;Application site anaesthesia
2525;Oropharyngeal spasm
2526;Tongue spasm
2527;Pulmonary vasculitis
2528;Choreoathetoid movements
2529;Convulsive disorder
2530;Convulsions aggravated
2531;Dysdiadochokinesis
2532;Delirium toxic
2533;Dizziness postural
2534;Dizziness exertional
2535;Head discomfort
2536;Head pressure
2537;Hypersensation skin
2538;Hypervigilance
2539;Fontanelle bulging
2540;Localised numbness
2541;Peripheral motor neuropathy
2542;Neurologic reaction
2543;Neurologic symptoms
2544;Neurotoxicity
2545;Paraesthesia skin
2546;Smarting
2547;Tingling skin
2548;Skeletal muscle paralysis
2549;Depression respiratory
2550;Scintillating scotoma
2551;Tetanus-like
2552;Tongue paralysis
2553;Tremor limb
2554;Tremor muscle
2555;Muscle contractions involuntary
2556;Paralysis of bladder
2557;Visual field constriction
2558;Withdrawal seizures
2559;Feeling tense
2560;Emotional poverty
2561;Withdrawal emotional
2562;Hunger abnormal
2563;Feeling strange
2564;Floating feeling
2565;Drug maladministration
2566;Euphoric mood
2567;Difficulty sleeping
2568;Nervous tremulousness
2569;Excitability
2570;Tranquillisation excessive
2571;Sedation
2572;Suicidal tendency
2573;Cerebration impaired
2574;Ejaculation decreased
2575;Ejaculation inhibited
2576;Skin warm
2577;Diastolic hypertension
2578;Lacrimal gland disorder
2579;Ciliary spasm
2580;Pupils pinpoint
2581;Dry throat
2582;Cycloplegia
2583;Vasoconstriction peripheral
2584;Hyperemesis
2585;Cataract subcapsular
2586;Chloropsia
2587;Conjunctival congestion
2588;Eye irritation
2589;Eye redness
2590;Keratopathy
2591;Retinal damage
2592;Ototoxicity
2593;Ear roaring
2594;Ear buzzing
2595;Dysosmia
2596;Taste bitter
2597;Taste peculiar
2598;Abdominal distress
2599;Epigastric pain not food-related
2600;Right upper quadrant pain
2601;Acid indigestion
2602;Upset stomach
2603;Faeces discoloured
2604;Fullness abdominal
2605;Gingival swelling
2606;Gastric hemorrhage
2607;Colon obstruction
2608;Small bowel obstruction
2609;Salivary gland pain
2610;Mouth irritation
2611;Buccal inflammation
2612;Buccal mucosa ulceration
2613;Black hairy tongue
2614;Tongue ulceration
2615;Tooth caries aggravated NOS
2616;Tooth hypoplasia
2617;Spasm biliary
2618;Hepatitis granulomatous
2619;Hepatotoxicity
2620;Fluid loss
2621;Hypertonicity
2622;Diabetes mellitus exacerbated
2623;Glucose tolerance abnormal
2624;Increased insulin requirement
2625;Blood uric acid increased
2626;Breath odour ketones
2627;Ketonemia
2628;Blood creatinine increased
2629;Fat tissue increased
2630;Gravitational oedema
2631;Ankle edema
2632;Azotaemia of renal origin
2633;Steroid withdrawal syndrome
2634;Anginal attack
2635;Angina pectoris aggravated
2636;Pulse abnormal
2637;Electrocardiogram QRS complex prolonged
2638;Paroxysmal atrial fibrillation
2639;Embolism limb
2640;Peripheral ischaemia
2641;Raynaud-like disorder
2642;Oral mucosal petechiae
2643;Thrombophlebitis of the leg
2644;Superficial phlebothrombosis
2645;Femoral artery thrombosis
2646;Vein disorder
2647;Vein pain
2648;Cardiac failure right
2649;Cyanosis peripheral
2650;Hypopnoea
2651;Laryngotracheal oedema
2652;Subglottic edema
2653;Pulmonary granuloma
2654;Respiratory tract hemorrhage
2655;Sneezing excessive
2656;Excessive bronchial secretion
2657;Haemoglobinaemia
2658;Hemolytic reaction
2659;Lymphadenopathy cervical
2660;Haemorrhage urinary tract
2661;Renal failure aggravated
2662;Loin pain
2663;Costovertebral angle tenderness
2664;Urine abnormality
2665;Perineal pain female
2666;Breast enlargement female
2667;Breast oedema
2668;Malignant neoplasm of female breast
2669;Uterine cervical lesion
2670;Galactorrhea not associated with childbirth
2671;Mastitis acute female
2672;Vaginal odour
2673;Vaginitis ulcerative
2674;Abdominal distension gaseous
2675;Back distress
2676;Chest discomfort
2677;Heaviness in limbs
2678;Reaction febrile
2679;Unexpected therapeutic effect
2680;Breath holding
2681;Saliva altered
2682;Hypertension worsened
2683;Haemangioma congenital
2684;Semen abnormal
2685;Nasal septum perforation
2686;Rheumatoid arthritis aggravated
2687;Psoriasis flare-up
2688;Malignant ovarian cyst
2689;Somnolence neonatal
2690;Breast pain male
2691;Mastitis male
2692;Pupillary reflex impaired
2693;Hair texture abnormal
2694;Bullous eruption
2695;Rash bullous
2696;Therapeutic response increased
2697;Overdose effect
2698;Therapeutic response decreased
2699;Hernia congenital
2700;Congenital diaphragmatic hernia
2701;Upper motor neurone lesion
2702;Fever neonatal
2703;Hyperhemoglobinemia
2704;Skin cold clammy
2705;Stomatitis necrotising
2706;Hyperbilirubinemia aggravated
2707;Pemphigoid reaction
2708;Sepsis secondary
2709;Lacrimation decreased
2710;Delayed delivery
2711;Exacerbation of disease
2712;Depression aggravated
2713;Mononeuritis
2714;Uterine inflammation
2715;Perforation stomach
2716;Leg edema
2717;Arthritis aggravated
2718;Migraine aggravated
2719;Allergy aggravated
2720;Implantation complication
2721;Lung infiltration
2722;Lacrimation abnormal NOS
2723;Myasthenia gravis-like syndrome
2724;Bronchospasm aggravated
2725;Hemorrhage of liver
2726;Nerve root lesion
2727;Breast neoplasm benign female
2728;Vestibular ataxia
2729;Crying abnormal
2730;Skull malformation
2731;Cerebral atrophy
2732;Zinc deficiency
2733;Diarrhoea, Clostridium difficile
2734;Dermatitis hemorrhagic
2735;Muscle necrosis
2736;Parkinsonism aggravated
2737;Rhinitis ulcerative
2738;Renal dysgenesis
2739;Dreaming excessive
2740;Ejaculation disorder
2741;Retinal deposits
2742;Pancreatic carcinoma
2743;Scleral discolouration
2744;Salivary duct obstruction
2745;Serum iron decreased
2746;Hepatic enzyme increased
2747;Pain neck/shoulder
2748;Jaw pain
2749;Mucosal swelling
2750;Aura
2751;Neoplasm malignant aggravated
2752;Periodontal destruction
2753;Pharyngeal oedema
2754;Oculomucocutaneous syndrome
2755;Polyposis gastric
2756;Tolerance development
2757;Mucosal ulceration
2758;Haptoglobin increased
2759;Edema of mouth
2760;Swollen tongue
2761;Throat tightness
2762;Bronchospasm paradoxical
2763;Cerebellar infarction
2764;Menopausal symptoms
2765;Scrotal pain
2766;Vaginal discomfort
2767;Vaginal pain
2768;Burning feeling vagina
2769;Neonatal and infancy disorder
2770;Photosensitivity allergic reaction
2771;Gastrointestinal obstruction
2772;Electrocardiogram abnormal specific
2773;Renal function test abnormal
2774;IUD complication
2775;Infection susceptibility increased
2776;Hemorrhage intraabdominal
2777;Alcohol withdrawal syndrome
2778;Acute reaction to stress
2779;Expressive language disorder
2780;Other sleep disturbances
2781;Dermoid cyst of ovary
2782;Heart rate irregular
2783;Dyschezia
2784;Skin peeling
2785;Gastrointestinal ulcer
2786;Breast cancer male
2787;Vasculitis cerebral
2788;Encephalitis cytomegalovirus
2789;Clostridium difficile colitis
2790;Radiation oesophagitis
2791;Necrotizing fasciitis
2792;Epidural haemorrhage
2793;Gastrointestinal stromal tumor
2794;Iodism
2795;Lithium toxicity
2796;Chronic interstitial nephritis
2797;Ischaemic neuropathy
2798;Nicotine poisoning
2799;Pancreatic abscess
2800;Sickle cell anaemia with crisis
2801;Renal vein thrombosis
2802;Anaplastic thyroid cancer
2803;Carcinoma papillary thyroid
2804;Aminoaciduria
2805;Anal inflammation
2806;Painful ankle
2807;Impairment of attention
2808;Bone lesion
2809;Bone marrow granuloma
2810;Bone tenderness
2811;Respiratory sounds decreased
2812;c-ANCA positive
2813;Chest X-ray normal
2814;Circumoral oedema
2815;Conjunctival irritation
2816;Coombs test positive
2817;Productive cough
2818;Creatinine low
2819;High-pitched crying
2820;Dactylitis
2821;Watery diarrhoea
2822;Oedema auricular
2823;Early satiety
2824;Low set ears
2825;Pain in elbow
2826;Eosinophiluria
2827;Epididymal tenderness
2828;Esophageal bleeding
2829;Oesophageal candidiasis
2830;Obstruction esophagus
2831;Oestrogen low
2832;Limb deformity
2833;Edema of lower extremities
2834;Acral erythema
2835;Numbness of limbs
2836;Pain of lower extremities
2837;Pain in arm
2838;Paresthesia of limbs
2839;Erythema of eyelid
2840;Erythema facial
2841;Numbness facial
2842;Pallor facial
2843;Facial paresthesia
2844;Facial rash
2845;Fat intolerance
2846;Pain in fingers
2847;Paresthesia of fingers
2848;Paraesthesia foot
2849;Genital pain
2850;Genital rash
2851;Gingival pain
2852;Grimacing
2853;Groin pain
2854;Hand dermatitis
2855;Edema hands
2856;Hand pain
2857;Paraesthesia hand
2858;Tremor of hands
2859;Headache dull
2860;Hematocrit increased
2861;Microscopic hematuria
2862;Glycosylated haemoglobin increased
2863;Fibrosis liver
2864;Frequent bowel movements
2865;Hypoalbuminemia
2866;Immunoglobulin G low
2867;Recurrent infection
2868;Lung fibrosis interstitial
2869;Intraventricular haemorrhage
2870;Iron deficiency
2871;Swelling of knees
2872;Shift to the left
2873;Leukonychia
2874;Paresthesia lips
2875;Lip swelling
2876;Lymph node tenderness
2877;Mg reduced
2878;Mg++ increased
2879;Menstruation delayed
2880;Taste metallic
2881;Muscle mass
2882;Nasal mucosal erythema
2883;Nasal sinus drainage
2884;Neck oedema of
2885;Nipple pain
2886;Nipple swelling
2887;Nipple tenderness
2888;Nasal irritation
2889;Nasal pain
2890;PTT prolonged
2891;Perineal laceration
2892;Perineal pain
2893;Personality change
2894;Plantar erythema
2895;Pregnancy test positive
2896;Prostate infection
2897;Prostatic pain
2898;Pulse pressure decreased
2899;Pupillary deformity
2900;Rectal mass
2901;Retinal exudates
2902;Salivary gland swelling
2903;Itchy scalp
2904;Scleral icterus
2905;Scrotal erythema
2906;Sensory ataxia
2907;Creatine phosphokinase serum increased
2908;Serum ferritin decreased
2909;Serum ferritin increased
2910;Sexually active
2911;Burning sensation skin
2912;Skin cysts
2913;Skin erosion
2914;Skin induration
2915;Pain of skin
2916;Pallor of skin
2917;Pustule
2918;Skin tenderness
2919;Skin thickening
2920;Skin tightness
2921;Spleen palpable
2922;Sputum purulent
2923;Dysstasia
2924;Mucous stools
2925;Subcutaneous abscess
2926;Suprapubic pain
2927;Testosterone low
2928;Increased thirst
2929;Burning tongue
2930;Protrusion tongue
2931;Thyrotropin low
2932;Urethral bleeding
2933;Vaginal burning sensation
2934;Vaginal cyst
2935;Vaginal dryness
2936;Vaginal erythema
2937;Venous occlusion
2938;Difficulty voiding
2939;Vulval erythema
2940;Weight fluctuation
2941;Wound haemorrhage
2942;Insufficiency cerebrovascular
2943;Diabetic
2944;Autoimmune hepatitis
2945;Hypomania
2946;Intestinal infarction
2947;Pulmonary congestion
2948;Violent
2949;Disease pelvic inflammatory
2950;Hypoxia
2951;Color blindness
2952;Coronary artery stenosis
2953;Furuncle
2954;Dyslipidemia
2955;Erectile dysfunction
2956;Disorder birth
2957;Herniated disk NOS
2958;Lung neoplasm malignant
2959;Edema retinal
2960;Parkinsonism
2961;Throat sore
2962;Prostatism
2963;Loeffler's syndrome
2964;Purpura nonthrombocytopenic
2965;Azotemia
2966;Autoimmune thrombocytopenia
2967;Vertical infection transmission
2968;Disease progression
2969;Retained placenta
2970;Left ventricular dysfunction
2971;Bronchiolitis obliterans with organizing pneumonia
2972;Drug - food interaction
2973;Breast neoplasm NOS male
2974;Injury to teeth
2975;Systemic inflammatory response syndrome
2976;Ventricular dysfunction
2977;Muscle fatigue
2978;Abdominal abscess
2979;Encephalitis viral
2980;Sepsis
2981;Aplasia
2982;Autonomic neuropathy
2983;Jarisch-Herxheimer reaction
2984;Wound dehiscence
2985;Punctate keratitis
2986;Xerosis
2987;Ketogenic diet
2988;Hearing disorders
2989;Mammogram abnormal
2990;Asymptomatic bacteriuria
2991;Autonomic nervous system imbalance
2992;Breast tenderness
2993;Cerebral dysfunction
2994;Cervical vertebral fracture
2995;Acute and chronic pancreatitis
2996;Collagen-vascular disease
2997;Spinal compression fracture
2998;Gallbladder polyp
2999;Gangrenous cholecystitis
3000;Nerve paralysis
3001;Night cramps
3002;Peripheral nerve injuries
3003;Renal mass
3004;Seroma
3005;Ventricular bigeminy
3006;Vulval abscess
3007;Decolouration skin
3008;Dermatitis psoriasiform
3009;Cutaneous vasculitis
3010;Skin fibrosis
3011;Abdominal wall abscess
3012;Perineal abscess
3013;Urticaria chronic
3014;Rash scarlatiniform
3015;Erythema annulare centrifugum
3016;Koebner phenomenon
3017;Keratosis pilaris
3018;Acne infantile
3019;Acne pustular
3020;Acne fulminans
3021;Dermatitis perioral
3022;Skin xerosis
3023;Ingrown hair
3024;Telogen effluvium
3025;Nail longitudinal striations
3026;Nail hypertrophy
3027;Onychomadesis
3028;Drug-induced lupus erythematosus
3029;Excessive granulation tissue
3030;Back disorder
3031;Rotator cuff syndrome
3032;Olecranon bursitis
3033;Soft tissue disorder
3034;Osteodystrophy
3035;Nasal ulcer
3036;Nasal septum ulceration
3037;Pharyngitis ulcerative
3038;Vocal cord disorder
3039;Glottic edema
3040;Bronchitis bacterial
3041;Bronchial ulceration
3042;Organising pneumonia
3043;Acute respiratory failure
3044;Pneumonia hypostatic
3045;Pulmonary ossification
3046;Pleural thickening
3047;Cardiac failure acute
3048;Dilatation atrial
3049;Conduction disorder
3050;Nodal arrhythmia
3051;Atrioventricular block second degree
3052;Wenckebach phenomenon
3053;Defect conduction intraventricular
3054;Polyangiitis
3055;Atheroma
3056;Purple toes syndrome
3057;Arterial occlusion
3058;Haemorrhoidal haemorrhage
3059;Vena cava thrombosis
3060;Superficial thrombophlebitis of leg
3061;Carotid artery occlusion
3062;Vasospasm cerebral
3063;Unspecified disease of pericardium
3064;Pyle's disease
3065;Limb reduction defect
3066;Pulmonary hypoplasia
3067;Congenital arterial malformation
3068;Netherton's syndrome
3069;Breast malformation
3070;Supernumerary nipple
3071;Congenital hydronephrosis
3072;Exencephaly
3073;Unspecified congenital anomaly of ear
3074;Blighted ovum
3075;Faecal occult blood positive
3076;Oral soft tissue disorder NOS
3077;Lip pain
3078;Lip ulcer
3079;Erosive esophagitis
3080;Reflux gastritis
3081;Gastroduodenitis
3082;Duodenal perforation
3083;Intestinal haemorrhages
3084;Ileitis regional
3085;Infarction mesenteric
3086;Mesenteric artery thrombosis
3087;Thrombosis mesenteric vessel
3088;Acute gastroenteritis
3089;Intestinal stenosis
3090;Ulcer colon
3091;Chronic idiopathic constipation
3092;Colon atonic
3093;Typhlitis
3094;Perirectal abscess
3095;Rectal hemorrhage
3096;Incisional hernia
3097;Hepatobiliary disease
3098;Hepatitis acute
3099;Hepatic congestion
3100;Hepatic cyst
3101;Acalculous cholecystitis
3102;Cholecystitis and cholelithiasis
3103;Bile duct stenosis
3104;Pancreatitis haemorrhagic
3105;Pancreatitis necrotising
3106;Pancreatic necrosis
3107;Hyperproteinaemia
3108;Disorders of fluid, electrolyte and acid-base balance
3109;Fluid retention
3110;Plasma osmolality increased
3111;Acidemia
3112;Copper deficiency
3113;Purine metabolism disorder
3114;Uricaciduria
3115;Pseudocholinesterase deficiency
3116;Cardiac amyloidosis
3117;Proximal renal tubular acidosis
3118;N-acetylglutamate synthase deficiency
3119;Hypermethioninemia
3120;Korsakoff's psychosis (non-alcoholic)
3121;Glomerulonephropathy
3122;Nephritic syndrome
3123;Acute nephritis
3124;Congenital single renal cyst
3125;Contracted bladder
3126;Scrotal disorder
3127;Scrotal ulcer
3128;Penile haemorrhage
3129;Fallopian tube cyst
3130;Uterine cyst
3131;Ectropion of cervix
3132;Uterine cervical squamous metaplasia
3133;Breast induration
3134;Haemorrhagic complications of pregnancy
3135;Antepartum hemorrhage
3136;Failed induction of labor
3137;Uterine hypertonus
3138;Suppressed lactation
3139;Perinatal disorder
3140;Vomiting neonatal
3141;Grey syndrome neonatal
3142;Nocturnal enuresis
3143;Psychotic depression
3144;Generalized anxiety disorder
3145;Brain injury
3146;Leukoencephalopathy
3147;Epidural abscess
3148;Transverse sinus thrombosis
3149;Lumbar puncture headache
3150;Hydrocephalus acquired
3151;Drug-induced parkinsonism
3152;Essential tremor
3153;Radiation myelopathy
3154;Quadriparesis
3155;Monoparesis
3156;Peroneal nerve palsy
3157;Petit mal status, epileptic
3158;Tonic seizures
3159;Axonal neuropathy
3160;Demyelinating polyneuropathy
3161;Toxic neuropathy
3162;Floppy infant
3163;Steroid myopathy
3164;Eye swelling
3165;Retinal scar
3166;Macular edema
3167;Cotton wool spots
3168;Stargardt's disease
3169;Cortical cataract
3170;Erythropsia
3171;Blindness, one eye
3172;Chemosis
3173;Blepharitis allergic
3174;Madarosis
3175;Sixth or abducens nerve palsy
3176;Ear haemorrhage
3177;Ceruminosis
3178;Otitis media acute
3179;Otitis media chronic
3180;Otitis media serous
3181;Eustachian tube disorder
3182;Growth hormone overproduction
3183;Hypogonadotrophic hypogonadism
3184;Glucose tolerance impaired
3185;Diabetic autonomic neuropathy
3186;Hypoglycemic reaction
3187;Secondary adrenocortical insufficiency
3188;Normochromic normocytic anaemia
3189;Hypochromic microcytic anemia
3190;Warm type haemolytic anaemia
3191;Evans syndrome
3192;Eosinopenia
3193;Heparin-induced thrombocytopenia
3194;Coagulation factor decreased
3195;Tonsillar disorder
3196;Tonsillar hypertrophy
3197;Lymph node abscess
3198;Mouth injury
3199;Femur shaft fracture
3200;Foot fracture
3201;Knee sprain
3202;Lung injury
3203;Nerve compression
3204;Graft complication
3205;Transfusion reaction
3206;Cholinergic syndrome
3207;Adrenergic syndrome
3208;Digoxin toxicity
3209;Toxic effect of other metals
3210;Infection mixed
3211;Bronchitis viral
3212;Viral pharyngitis
3213;Encephalitis herpes
3214;Cytomegalovirus hepatitis
3215;Pneumonia cytomegaloviral
3216;Aspergilloma
3217;Candida albicans infection
3218;Balanitis candida
3219;Gastric flu
3220;Psychic disorder NOS
3221;Drug intolerance
3222;Found dead (cause undetermined)
3223;Strangulation
3224;Prostration
3225;Intermittent fever
3226;Blood pressure systolic increased
3227;Blood pressure systolic decreased
3228;Blood pressure diastolic increased
3229;Blood pressure diastolic decreased
3230;Pulse absent
3231;Venous stasis
3232;Peripheral coldness
3233;Blanching of skin
3234;Dry hair
3235;Oily hair
3236;Gingival oedema
3237;Change of bowel habit
3238;Faeces hard
3239;Cloudy urine
3240;Urine odour abnormal
3241;Mental state abnormal
3242;Dependence psychological
3243;Dependence physiological
3244;Ejaculation failure
3245;Painful ejaculation
3246;Equilibrium loss
3247;Sensory loss
3248;Radicular pain
3249;Facial spasm
3250;Carcinoma breast stage IV
3251;Osteosarcoma metastatic
3252;Metastatic renal cell carcinoma
3253;Metastatic melanoma
3254;Anal carcinoma
3255;Refractory anemia with excess blasts in transformation
3256;Solid tumour
3257;Oropharyngeal squamous cell carcinoma
3258;Adenocarcinoma pancreas
3259;Acute glaucoma
3260;Acute psychosis
3261;Anal abscess
3262;Meningioma benign
3263;Endotracheal intubation complication
3264;Dysequilibrium
3265;Oesophageal rupture
3266;Generalized aching
3267;Wound haematoma
3268;Hepatitis C antibody positive
3269;Muscle swelling
3270;Musculoskeletal deformity
3271;Pelvic peritonitis
3272;Red cell aplasia
3273;Skin mass
3274;Skin swelling
3275;Scrotal swelling
3276;Biliary sludge
3277;Aplasia cutis congenita
3278;Iron overload
3279;Cystitis interstitial
3280;Leukostasis
3281;Prostatic intraepithelial neoplasia
3282;Eruption
3283;Osteolytic lesion
3284;Xanthoma
3285;Parainfluenzae virus infection NOS
3286;Disorder calcium (NOS)
3287;Cervix carcinoma
3288;Hepatitis fulminant
3289;Uraemic syndrome
3290;Obsessional neurosis
3291;Protein-losing gastroenteropathy
3292;Euthyroid goiter
3293;Microcytic
3294;Lymphocytoma cutis
3295;Frozen shoulder
3296;Abdominal obesity
3297;Walking difficulty
3298;Bilirubin increased
3299;Spotting menstrual
3300;Hypersexuality
3301;Blacked-out (not amnesia)
3302;Dryness of eyes
3303;Induration
3304;Papule
3305;Macule
3306;Redness
3307;Lividity
3308;Cushingoid facies
3309;Burns second degree
3310;Scald
3311;Open wound
3312;Pneumatosis
3313;Pitting edema
3314;Edema transient
3315;Lymphorrhoea
3316;Bloody discharge
3317;Splinter haemorrhages
3318;Ulcer haemorrhage
3319;Mucositis
3320;Epidermolysis
3321;Phlebosclerosis
3322;Tumour necrosis
3323;Lacunar infarction
3324;Dystrophic calcification
3325;Chrysiasis
3326;Atrophy
3327;Fat atrophy
3328;Hypochromasia
3329;Dysplasia
3330;Epidermal nevus
3331;Malignant mesenchymoma
3332;Anaplastic astrocytoma
3333;Mantle cell lymphoma
3334;Intravascular large B-cell lymphoma
3335;Uterine sarcoma NOS
3336;Aseptic peritonitis
3337;Common migraine
3338;Intracranial venous sinus thrombosis
3339;Sagittal sinus thrombosis
3340;Transient global amnesia
3341;Psychotic episode
3342;Toxic confusional state
3343;Cognitive impairment
3344;Mania
3345;Anxiety depression
3346;Arcus juvenilis
3347;Perforation corneal
3348;Chorioretinopathy
3349;Choroidal effusion
3350;Retinopathy proliferative
3351;Arteriosclerotic retinopathy
3352;House dust allergy
3353;Viral upper respiratory tract infection
3354;Pneumonia fungal
3355;Tracheal fistula
3356;Pregnancy induced hypertension
3357;Atrial hypertrophy
3358;Ventricular hypertrophy
3359;Inferior myocardial infarction
3360;Ectopic beats
3361;Myocardial depression
3362;Renal artery thrombosis
3363;Arterial aneurysm
3364;Aortic dissection
3365;Thrombophlebitis leg deep
3366;Embolism venous
3367;Electromechanical dissociation
3368;Anaphylactoid reaction
3369;Prosthetic cardiac valve thrombosis
3370;Arteriovenous fistula thrombosis
3371;Secondary anemia
3372;Oral herpes
3373;Parotid gland enlargement
3374;Esophageal erosions
3375;Gastric ulcer perforation
3376;Bleeding gastric ulcer
3377;Gastric erosions
3378;Gastrointestinal fistula
3379;Duodenitis hemorrhagic
3380;Enterocutaneous fistula
3381;Cytomegalovirus colitis
3382;Chronic liver disease
3383;Peritonitis bacterial
3384;Chemical peritonitis
3385;Retroperitoneal haematoma
3386;Fanconi syndrome acquired
3387;Acute retention of urine
3388;Bladder necrosis
3389;Pelvic fibrosis
3390;Endometriosis of uterus
3391;Diabetes with unspecified complications
3392;Neuroglycopenia
3393;Pituitary infarction
3394;Pituitary haemorrhage
3395;Early menarche
3396;Electrolyte imbalance
3397;Anion gap increased
3398;Vascular calcification
3399;Homozygous familial hypercholesterolaemia
3400;Heterozygous familial hypercholesterolemia
3401;Hypolipidaemia
3402;Nail infection
3403;Urticaria physical
3404;Capillary leak syndrome
3405;Effusion of knee
3406;Chondrolysis
3407;Gastroenteritis adenovirus
3408;Helicobacter gastritis
3409;Neutropenic enterocolitis
3410;Methicillin-resistant Staphylococcus aureus infection
3411;Risus sardonicus
3412;Lockjaw
3413;Genital candidiasis
3414;Anal candidiasis
3415;Gastrointestinal candidiasis
3416;Blurred vision
3417;Abdominal pain generalised
3418;Depressed mood
3419;Vivid dreams
3420;Collapse
3421;Nocturnal dyspnea
3422;Incomplete bladder emptying
3423;Stomach cramps
3424;Monomorphic ventricular tachycardia
3425;Multifocal ventricular tachycardia
3426;Cloacal exstrophy
3427;Anal skin tags
3428;Malignant neoplasm of liver, not specified as primary or secondary
3429;Hepatic angiosarcoma
3430;Milia
3431;Benign neoplasm of breast
3432;Pituitary microadenoma
3433;Choroidal nevus
3434;Chronic eosinophilic leukemia
3435;Malignant neoplasm of pancreas
3436;Metastases to peritoneum
3437;Oral neoplasm benign
3438;Papilloma skin
3439;Back strain
3440;Chest mass NOS
3441;Asthmatic attack
3442;Dysfunction thyroid
3443;Pneumonia due to Streptococcus, group b
3444;Manic episode
3445;Depressive episode
3446;Phobia
3447;Paranoid delusions
3448;Organ failure
3449;Photosensitivity
3450;Corneal scar
3451;Haemoglobin abnormal
3452;Ischemic cardiomyopathy
3453;Exacerbation of asthma
3454;Nausea alone
3455;Bell's palsy
3456;Avitaminosis
3457;Amaurosis
3458;Cardiac death
3459;Premenstrual tension
3460;Malignant neoplasm of prostate
3461;Haematological malignancy
3462;Alcoholic pancreatitis
3463;PCO2
3464;Abnormality of red blood cells
3465;Hepatic atrophy
3466;Anaesthetic complication
3467;Enlargement abdomen
3468;Gastroesophagitis
3469;Ovarian enlargement
3470;Hepatic artery thrombosis
3471;Akathisia
3472;Application site atrophy
3473;Clamminess
3474;Corneal erosion
3475;Drug effect prolonged
3476;Emprosthotonus
3477;Influenza-like symptoms
3478;Hemorrhage kidney
3479;Gastric irritation
3480;Repetitive speech
3481;Injection site urticaria
3482;Warmth
3483;Gingival ulceration
3484;Platelet count decreased
3485;Hepatitis B e antigen positive
3486;Calcium deficiency
3487;Nephrolithiasis
3488;Cauda equina syndrome
3489;Nuclear cataract
3490;Postoperative infection
3491;Alcohol poisoning
3492;Exhaustion
3493;Hyperpyrexia
3494;Pulse irregular
3495;Dysesthesia
3496;Abnormal involuntary movements
3497;Shakiness
3498;Atopy
3499;Meningitis chemical
3500;Transient insomnia
3501;Initial insomnia
3502;Middle insomnia
3503;Multifocal motor neuropathy
3504;Cholinergic crisis
3505;Disequilibrium syndrome
3506;Psychogenic polydipsia
3507;Lipoedema
3508;Thrombophilia
3509;Protein C deficiency
3510;Oral discomfort
3511;Oral mucosa erosion
3512;Colitis microscopic
3513;Lymphocytic colitis
3514;Neutropenic colitis
3515;Solitary rectal ulcer
3516;Postoperative ileus
3517;Fungal peritonitis
3518;Constipation chronic
3519;Chronic diarrhea
3520;Chronic renal insufficiency
3521;Goodpasture's syndrome
3522;Chronic allograft nephropathy
3523;Chemical cystitis
3524;Atonic urinary bladder
3525;Retrograde ejaculation
3526;Candiduria
3527;Ovarian atrophy
3528;Vaginal infection
3529;Obstetric procedure complication
3530;Nipple disorder
3531;Adrenal cortical hypofunction
3532;Photoonycholysis
3533;Eosinophilic pustular folliculitis
3534;Plaque psoriasis
3535;Steroid acne
3536;Sebaceous hyperplasia
3537;Linear IgA bullous dermatosis
3538;Wound secretion
3539;Joint injury
3540;Localized osteoarthritis
3541;Lupus erythematosus
3542;Muscle damage
3543;Proximal myopathy
3544;Muscle injury
3545;Avascular necrosis femoral head
3546;Unspecified deformity of finger
3547;Death neonatal
3548;Tachycardia foetal
3549;Bradycardia foetal
3550;Foetal acidosis
3551;Acute allergic reaction
3552;Mosquito bite
3553;Halo vision
3554;Oscillopsia
3555;Eye discharge
3556;Eye bleeding
3557;Staring
3558;Dermatochalasis
3559;Lacrimation
3560;Dacryocanaliculitis
3561;Sunken eyes
3562;Corneal pigmentation
3563;Corneal staining
3564;Punctate epithelial erosion
3565;Scleral hyperaemia
3566;Scleral thinning
3567;Anterior chamber flare
3568;Anterior chamber cell
3569;Keratic precipitates
3570;Posterior vitreous detachment
3571;Sensation of foreign body
3572;Throbbing headache
3573;Teething pain
3574;Cardiac pain
3575;Urinary tract pain
3576;Painful respiration
3577;Micturition burning
3578;Skin thinness
3579;Skin scaly
3580;Rash maculo-papular
3581;Increased tendency to bruise
3582;Splitting nails
3583;Nail thinning
3584;Growth of eyelashes
3585;Suicidal ideation
3586;Delusional perception
3587;Hypnopompic hallucination
3588;Decreased interest
3589;Tearfulness
3590;Psychomotor retardation
3591;Behavior hyperactive
3592;Social disinhibition
3593;Violent behavior
3594;Breath holding attack
3595;Teeth clenching
3596;Mask like facies
3597;Chapped lips
3598;Vasovagal symptoms
3599;Unspecified delay in development
3600;Cold hands
3601;Cold feet
3602;Postoperative fever
3603;Rigors
3604;Periorbital swelling
3605;Orbital oedema
3606;Parotid swelling
3607;Gasping
3608;Respiratory sighs
3609;Respiration irregularity
3610;Dropped beats
3611;Midsystolic click
3612;Abdominal aortic bruit
3613;Prolonged menses
3614;Short period
3615;Bladder spasm
3616;Tongue dry
3617;Gastrointestinal symptom NOS
3618;Appetite exaggerated
3619;Fluid intake increased
3620;Fluid intake reduced
3621;Excessive flatulence
3622;Defaecation urgency
3623;Bowel spasm
3624;Prostatomegaly
3625;Anal bleeding
3626;Tibial torsion
3627;Akinaesthesia
3628;Stiffness
3629;Facial paresis
3630;Jerky movement NOS
3631;Movements involuntary
3632;Unsteadiness
3633;Toe walking
3634;Parkinsonian gait
3635;Red blood cell count decreased
3636;Red blood cell count increased
3637;Lymphocyte abnormal
3638;Platelet count normal
3639;Fraction of inspired oxygen
3640;Bicarbonate level
3641;Serum creatinine decreased
3642;Progesterone levels
3643;MAP
3644;Labile blood pressure
3645;Sinoatrial node dysfunction
3646;QRS voltage decreased
3647;Arrhythmia supraventricular
3648;Bradycardia
3649;Nodal tachycardia
3650;Electrocardiogram ST segment
3651;T amplitude decreased
3652;QRS complex
3653;Anovulatory cycle
3654;Residual urine volume
3655;Post transplant lymphoproliferative disorder
3656;Joint sprain
3657;Subluxation hip
3658;Ligament injury
3659;Wrist fracture
3660;Hand fracture
3661;Chest X-ray abnormal
3662;Urine analysis abnormal
3663;Electrocardiogram T wave abnormal
3664;Electrocardiogram QRS complex abnormal
3665;Laboratory test abnormal
3666;Liver function test normal
3667;Liver enzyme abnormal
3668;Blood urea normal
3669;Blood urea abnormal
3670;Serum creatinine abnormal
3671;Urine electrolytes abnormal
3672;Scotoma annular
3673;Chest pressure
3674;Transaminases increased
3675;Dependence
3676;Hypoperfusion
3677;Neuropathy
3678;Secondary infection
3679;Urolithiasis
3680;Word finding difficulty
3681;Homicidal ideation
3682;Energy increased
3683;Poor urinary stream
3684;Pharyngeal erythema
3685;Sepsis neonatal
3686;Ear canal erythema
3687;Sleep paralysis
3688;Total spinal block
3689;Blindness
3690;Hemiparesis (left)
3691;Dermatitis eyelid
3692;Genital pain male
3693;Ovarian pain
3694;Complex regional pain syndrome
3695;Psychotic state
3696;Large intestinal obstruction
3697;Ischaemic hepatitis
3698;Intra-abdominal haematoma
3699;Perirenal haematoma
3700;Frank hematuria
3701;Haemorrhagic ovarian cyst
3702;Hair colour changes
3703;Chromatopsia
3704;Increased activity
3705;Corneal stromal edema
3706;Haemoglobin normal
3707;Pelvic haematoma
3708;Light anaesthesia
3709;Nasal oedema
3710;Pruritus generalised
3711;Carcinoma endometrial
3712;Dyslexia
3713;Respiratory distress
3714;Musculoskeletal chest pain
3715;Non-cardiac chest pain
3716;Gas pain
3717;Serum amylase increased
3718;Blood gases abnormal
3719;Echocardiogram abnormal
3720;Electroretinogram abnormal
3721;Pulmonary function test abnormal
3722;Thyroid function test abnormal
3723;Smear cervix abnormal
3724;Found dead
3725;Generalized lymphadenopathy
3726;Other forms of epilepsy
3727;Prothrombin time ratio
3728;Metastases to liver
3729;Tonic-clonic seizures
3730;Mononeuropathies
3731;Inner ear disorder
3732;Benign neoplasms of liver
3733;Benign neoplasm of brain
3734;Pituitary neoplasm benign
3735;Lymphadenopathy
3736;Abnormal sensation in eye
3737;Abnormal eye movements NOS
3738;Conjunctivitis infective
3739;Other disorders of eye
3740;Blood pressure increased
3741;Dementia
3742;Localized rash
3743;Rash generalised
3744;Moniliasis genital female
3745;Penile pain
3746;Benign neoplasm of other parts of digestive system
3747;Unspecified congenital anomaly of brain, spinal cord, and nervous system
3748;Tooth abscess
3749;Pneumonia due to Klebsiella pneumoniae
3750;Pulmonary lymphoma
3751;Necrotizing enterocolitis
3752;Chronic active hepatitis
3753;Aseptic necrosis of bone
3754;Prostatic adenoma
3755;Subcutaneous haematoma
3756;Hypertensive episode
3757;Rebound hypertension
3758;Pulmonary microemboli
3759;Poor peripheral circulation
3760;Numbness of tongue
3761;Toxic dilatation of intestine
3762;Ileal ulcer
3763;Biliary fibrosis
3764;Buffalo hump
3765;Acute pyelonephritis
3766;Vulvovaginal discomfort
3767;Vulvovaginal dryness
3768;Breast microcalcification
3769;Obstructive sleep apnea syndrome
3770;Periorbital haematoma
3771;Subconjunctival cyst
3772;Coombs positive hemolytic anemia
3773;Delayed recovery from anesthesia
3774;Neuromuscular block prolonged
3775;Radiation recall syndrome
3776;Sudden death, cause unknown
3777;Pleurothotonus
3778;Forced expiratory volume decreased
3779;Mean arterial pressure decreased
3780;Venous pressure jugular increased
3781;Diastolic dysfunction
3782;Stroke volume increased
3783;Electrocardiogram PR shortened
3784;ST elevated
3785;ST depressed
3786;T wave inverted
3787;Localized exfoliation
3788;Increased skin sensitivity
3789;Nausea postoperative
3790;Spermatogenesis abnormal
3791;Pain localised
3792;Coordination abnormal
3793;Neoplasm recurrence
3794;Rash psoriaform
3795;Vasculitic rash
3796;Compression fracture
3797;Osteoporotic fracture
3798;Eschar
3799;Accident at home
3800;Skin oedema
3801;Toxic skin eruption
3802;Systemic lupus erythematosus rash
3803;Nail bed infection
3804;Oedema mucosal
3805;Application site irritation
3806;Application site pain
3807;Application site ulcer
3808;Application site pigmentation changes
3809;Application site rash
3810;Application site infection
3811;Injection site irritation
3812;Injection site pigmentation changes
3813;Injection site extravasation
3814;Injection site thrombosis
3815;Injection site burning
3816;Injection site dermatitis
3817;Injection site paraesthesia
3818;Injection site ulcer
3819;Injection site bruising
3820;Injection site induration
3821;Implant site reaction
3822;Polymyalgia
3823;Brain stem haemorrhage
3824;Congenital joint malformation
3825;Congenital vesicoureteric reflux
3826;Paraesthesia oral
3827;Hypoaesthesia oral
3828;Pseudoporphyria
3829;Pelvi-ureteric obstruction
3830;Hydroureter
3831;Bilateral hydronephrosis
3832;Bladder fibrosis
3833;Genital itching male
3834;Genital itching female
3835;Neurological impairment
3836;Hemiplegia transient
3837;Retinal atrophy
3838;Cataract unilateral
3839;Influenza like illness
3840;Drug effect decreased
3841;Pre-existing disease
3842;Stress symptoms
3843;Upper limb oedema
3844;Loss of control of legs
3845;Cough suppression
3846;Acute chest pain
3847;Electrocardiogram abnormal
3848;Carbohydrate craving
3849;Abdominal pain localised
3850;Impaired gastric emptying
3851;Regurgitation of food
3852;Liver pain
3853;Urine color abnormal
3854;Feeling of relaxation
3855;Sense of oppression
3856;Feeling drunk
3857;Self-injurious ideation
3858;Visual evoked potentials abnormal
3859;Paralysed
3860;Feeling hot and cold
3861;Sinus pain
3862;Eye rolling
3863;Ear feels clogged
3864;Vertigo positional
3865;Inflammation localised
3866;Metabolic syndrome X
3867;Dependence on opiates
3868;Pulmonary thromboembolism
3869;Chronic hepatitis B
3870;Mood disorder NOS
3871;Abscess sterile
3872;Hepatic adenoma
3873;Aggravation of existing disorder
3874;Platelet aggregation abnormal
3875;Ammonia increased
3876;Sinus arrest
3877;Awakening early
3878;Bad taste
3879;Bicarbonate decreased serum
3880;Burning rectal
3881;Carbohydrate tolerance decreased
3882;Choreiform
3883;Chromaturia
3884;Contraction skeletal muscle
3885;Deposit eye
3886;Detachment psychological
3887;Difficulty focusing eyes
3888;Difficulty thinking
3889;Discomfort rectal
3890;Spermatozoa abnormal
3891;Disulfiram like reaction
3892;Duodenal ulcer aggravated
3893;Dystonic reaction
3894;Eczema allergic atopic
3895;Lip oedema
3896;Erection increased
3897;Excitation cerebral
3898;Fuzzy head
3899;Gas in stomach
3900;Cerebral haematoma
3901;Injection site haematoma
3902;Hypercoagulation
3903;Hypoplasia erythroid
3904;Incoherent
3905;Instability vasomotor
3906;Coronary artery insufficiency
3907;Local throat irritation
3908;Nasal burning
3909;Injection site nodule
3910;Oversedation
3911;Injection site phlebitis
3912;Pseudoparkinsonism
3913;Rash pemphigoid
3914;Reaction gastrointestinal
3915;Water retention
3916;Slough injection site
3917;Speech loss
3918;Spots before eyes
3919;Thrombophlebitis injection site
3920;Tired and heavy
3921;Toxic reaction (NOS)
3922;Tremulousness
3923;Sleep talking
3924;Pimples
3925;Battery
3926;Forgetfulness
3927;Renal agenesis
3928;Face oedema
3929;Feces bloodstained
3930;Hypersensitive syndrome
3931;Orthostatic hypertension
3932;Mucosal erosion
3933;Fluid overload
3934;Hypovolemia
3935;Choking sensation
3936;Brittle nails
3937;Atrial tachycardia
3938;Joint lock
3939;Visual disturbance
3940;Distress gastrointestinal
3941;Embolism arterial
3942;Pseudofolliculitis barbae
3943;Asteatosis
3944;Chapped skin
3945;Feeling jittery
3946;Myasthenic syndrome
3947;Nail discomfort
3948;Arthralgia aggravated
3949;Dizziness aggravated
3950;Depressed level of consciousness
3951;Jaw stiffness
3952;Bladder dilatation
3953;Loss of confidence
3954;Anxiety aggravated
3955;Rebound effect
3956;Sensation of blood flow
3957;Abdominal pain aggravated
3958;Gastritis aggravated
3959;Nausea aggravated
3960;Fibrillation atrial aggravated
3961;Pelvic venous thrombosis
3962;Nasal soreness
3963;Neutropenia aggravated
3964;Auricular swelling
3965;Vaginal mycosis
3966;Benign hydatidiform mole
3967;Eyelid infection
3968;Parotid duct obstruction
3969;Bone pain aggravated
3970;Asthma aggravated
3971;Neck tightness
3972;Ischial neuralgia
3973;Conjunctivitis exacerbated
3974;Inflicted injury
3975;Abdominal adhesions
3976;Hot dry skin
3977;Pancreatic enzymes increased
3978;Larynx pain
3979;Lumbar disc lesion
3980;Plasma osmolality decreased
3981;Ovarian hyperstimulation
3982;Hypotonic-hyporesponsive episode
3983;Feeling of body temperature change
3984;Sensation of warmth
3985;Wound discharge increased
3986;Bladder discomfort
3987;Alcohol problem
3988;Blood urea decreased
3989;Nasal septum deviation
3990;Meibomianitis
3991;Low density lipoprotein increased
3992;Apgar score low
3993;Blood pressure fluctuation
3994;Urine flow decreased
3995;Skin fragility
3996;Nicotinic effects
3997;Surgical site reaction
3998;Procedural site reaction
3999;Surgical intervention
4000;Vein discolouration
4001;Anaemia NOS aggravated
4002;Urine odour foul
4003;Hemoglobin increased
4004;Oesophageal reflux aggravated
4005;Localised skin reaction
4006;Traumatic haematoma
4007;Thyroid carcinoma
4008;Lipase increased
4009;Device expulsion
4010;Alveolitis
4011;Monocyte count decreased
4012;Pigmentation disorders
4013;Dysfunction adrenal
4014;Sexual dysfunction
4015;Lipids abnormal
4016;Potassium abnormal NOS
4017;Angiitis necrotising
4018;Systemic mycosis
4019;Labored breathing
4020;Hypofibrinogenemia
4021;Brain herniation
4022;Reversible ischaemic neurological deficit
4023;Hemorrhage brain
4024;Monocyte count increased
4025;Ca++ increased
4026;Serum potassium increased
4027;Serum phosphate increased
4028;Breast pain female
4029;Sweating decreased
4030;Squamous cell carcinoma of skin
4031;Chondrocalcinosis
4032;PRL increased
4033;Prothrombin level decreased
4034;Cervical discharge
4035;Endomyocardial fibrosis
4036;Azotemia prerenal
4037;Bradyphrenia
4038;White blood cells urine increased
4039;Morbid thoughts
4040;Lip dry
4041;Nose infection NOS
4042;Oral infection
4043;Alcohol craving
4044;Drug craving
4045;Skin maceration
4046;Yellow skin
4047;Gastroenteritis bacterial
4048;Carcinoma of tongue
4049;Vaginal irritation
4050;Skin laceration
4051;Renal pain
4052;Stress at work
4053;Functional gastrointestinal disorder
4054;Ileal perforation
4055;Swelling of eyelid
4056;Unable to walk
4057;Genital injury
4058;Burning in throat
4059;Persistent cough
4060;Gastritis viral
4061;Albumin urine present
4062;Genital infection male
4063;Vaginal swelling
4064;Vaginal ulceration
4065;Uterine pain
4066;Lithium poisoning
4067;Foot edema
4068;Cough increased
4069;Rib pain
4070;Skin bleeding
4071;Body hair loss
4072;Lower urinary tract symptoms
4073;Sacroiliitis
4074;Abnormality of gait
4075;Balance disorder
4076;Hand swelling
4077;Hands weakness of
4078;Genu valgum
4079;Lhermitte's sign
4080;Pharyngeal haemorrhage
4081;Soft stools
4082;Mass
4083;Swollen arm
4084;Allergy to nuts
4085;Latex allergy
4086;Family stress
4087;Heart sounds abnormal
4088;Lymph node pain
4089;Antibiotic-associated diarrhea
4090;Neck swelling
4091;Abscess limb
4092;Eyebrow loss of
4093;Sore eye
4094;Lymphadenopathy axillary
4095;Lymphadenopathy inguinal
4096;Jessner's lymphocytic infiltration
4097;Platelet count abnormal
4098;Prothrombin time abnormal
4099;Prothrombin time shortened
4100;International normalised ratio abnormal
4101;Serum albumin decreased
4102;White blood cell count abnormal
4103;Blood glucose abnormal
4104;Digoxin level increased
4105;Chronic anxiety
4106;Multiple sclerosis exacerbation
4107;Swelling of legs
4108;Penile infection
4109;Pain hunger
4110;Felt faint
4111;Complete hearing loss
4112;Sensation of heaviness
4113;Writing impaired
4114;Cutaneous hypersensitivity
4115;Thyrotropin high
4116;Numbness in fingers
4117;Limb paresis
4118;Implant infection
4119;Genitourinary chlamydia infection
4120;Parasuicide
4121;Calcium intoxication
4122;Blood glucose increased
4123;Blood sodium increased
4124;Sodium high
4125;Serum calcium decreased
4126;Blood glucose decreased
4127;Serum potassium decreased
4128;Blood chloride increased
4129;Blood chloride decreased
4130;Nephropathy toxic
4131;Serum calcium increased
4132;Cholesterol serum elevated
4133;Blood cholesterol increased
4134;Increased effect
4135;Stillbirth
4136;Binge eating
4137;Cancer pain
4138;Gas
4139;Skeletal injury
4140;Nephrotoxicity
4141;Bladder infection
4142;Compulsions
4143;Electrocardiogram PR prolongation
4144;Prostate carcinoma
4145;Hot flushes
4146;Cardiopulmonary arrest
4147;Disease obstructive lung
4148;Syndrome toxic shock
4149;Carcinoma testes
4150;Stinging
4151;Stridor inspiratory
4152;Breast disorder female
4153;Emotional problems
4154;Brain stem glioma
4155;Carcinoma breast
4156;Obsessive thoughts
4157;Disease recurrence
4158;Vascular rupture
4159;Vascular stenosis
4160;Platelet dysfunction
4161;Consciousness clouding
4162;Depersonalization syndrome
4163;Carcinoma of lung
4164;Hemophilia
4165;Metastases to spine
4166;Congenital limb hyperextension
4167;Muscular ventricular septal defect
4168;Gastrointestinal neoplasm malignant
4169;Dyskinesia tardive
4170;Drug interaction
4171;Pregnancy loss
4172;Anorectal disorder
4173;Gastrointestinal pain
4174;Drug seeking behavior
4175;Systolic ejection murmur
4176;Community acquired pneumonia
4177;Excessive daytime sleepiness
4178;Macular fibrosis
4179;Tracheostomy infection
4180;Ear infection
4181;Carcinoma colon
4182;Carcinoma stomach
4183;Serotonin syndrome
4184;Bladder carcinoma
4185;Skin carcinoma
4186;Anxiety attack
4187;Idiopathic hypertrophic subaortic stenosis
4188;Motor restlessness
4189;Tendon reflex decreased
4190;Throat irritation
4191;Aspiration
4192;Presyncope
4193;Dyssomnias
4194;Serum creatinine increased
4195;Hypoxemia
4196;Vulvovaginal candidiasis
4197;Emotional distress
4198;Rhythm idioventricular
4199;Primary hypothyroidism
4200;Chronic peptic ulcer
4201;Mobility decreased
4202;Sweating increased
4203;Radiculopathy
4204;Anxiety state
4205;Congenital hypertrophic pyloric stenosis
4206;Long-term memory loss
4207;Short-term memory loss
4208;Onychia
4209;Staggering gait
4210;Thermal burn
4211;Erythropoiesis abnormal
4212;Polyarthropathy
4213;Trichorrhexis
4214;Acne
4215;Basophilia
4216;Low pH
4217;Intoxication
4218;Unspecified circulatory system disorder
4219;Spotting vaginal
4220;Gastrointestinal fungal infection
4221;Genital infection
4222;Infectious meningitis
4223;Central serous retinopathy
4224;Microalbuminuria
4225;Maculopathy
4226;Bile duct carcinoma
4227;Pelvic peritoneal adhesions
4228;Cerebellar atrophy
4229;Multiple allergies
4230;5'nucleotidase increased
4231;Blood culture positive
4232;COPD exacerbation
4233;Ultrasound breast abnormal
4234;Physical assault
4235;Genital infection fungal
4236;Hydrocortisone decreased
4237;Varicella zoster
4238;Hyperuricemia
4239;Auditory and visual hallucinations
4240;Duodenal ulcer perforation
4241;Psychotic behaviour
4242;Delayed gastric emptying
4243;Taste altered
4244;Direct bilirubin increased
4245;Bilirubin unconjugated increased
4246;Acute diarrhea
4247;Diabetic peripheral neuropathy
4248;Kidney cancer
4249;Electrolytes NOS decreased
4250;Albumin high
4251;Creatinine abnormal NOS
4252;Calcium abnormal NOS
4253;Hypotension asymptomatic
4254;Hypotension orthostatic symptomatic
4255;Abdominal symptom
4256;Adnexal torsion
4257;End stage AIDS
4258;Upper airway obstruction
4259;Substance abuse
4260;Antibody test positive
4261;Aortic aneurysm rupture
4262;Autonomic dysfunction
4263;Bedridden
4264;Bilirubin total increased
4265;Hemorrhage abnormal
4266;Cardiac enzymes increased
4267;Carotid sinus hypersensitivity
4268;Catheter infection
4269;Catheter sepsis
4270;Cerebritis
4271;Candida cervicitis
4272;Chest heaviness
4273;C-reactive protein increased
4274;Eosinophilic cystitis
4275;Psychosis depressive
4276;Urine drug screen positive
4277;Acute dyspnea
4278;Ejection fraction decreased
4279;Endometrial thickening
4280;Enterobacter sepsis
4281;Oesophageal irritation
4282;Limb injury
4283;Eye oedema
4284;Febrile disorders
4285;Acute febrile illness
4286;Diabetic foot infection
4287;Foot infection fungal NOS
4288;Friction rub
4289;Fungal sepsis
4290;Genital lesion
4291;Gingival infection
4292;Hematocrit decreased
4293;Hypereosinophilia
4294;Hypoglycaemic episode
4295;Junctional bradycardia
4296;Klebsiella sepsis
4297;End stage liver disease
4298;Hepatic granuloma
4299;Liver nodule
4300;Acute myocardial ischemia
4301;Febrile neutropenia
4302;Oxygen saturation decreased
4303;Ovarian failure
4304;Infection parasitic
4305;Increased prolactin level
4306;Prostatic acid phosphatase increased
4307;Bacterial prostatitis
4308;Erythrodermic psoriasis
4309;Psychiatric decompensation
4310;Progressive renal failure
4311;Scleral haemorrhage
4312;Scleral pigmentation
4313;Allergic sinusitis
4314;Submandibular mass
4315;Wide complex tachycardia
4316;Pharyngeal lesion
4317;Urinary abnormalities
4318;Generalized urticaria
4319;Vaso-occlusive crisis
4320;Non-sustained ventricular tachycardia
4321;Sustained ventricular tachycardia
4322;Unilateral vision loss
4323;White blood cell count decreased
4324;White blood cell count high
4325;Yeast infection
4326;Alkaline phosphatase serum increased
4327;Phlebitis superficial
4328;Chronic insomnia
4329;Learning disability
4330;Memory loss
4331;Pain nerve
4332;Tetrahydrobiopterin deficiency
4333;Phonophobia
4334;Retching reflex decreased
4335;Convulsive seizure
4336;Focal seizures
4337;Nonconvulsive status epilepticus
4338;Cardiac syncope
4339;Pill rolling
4340;Vocal cord paresis
4341;Lymphangioleiomyomatosis
4342;Anterior ischemic optic neuropathy
4343;Ataxic gait
4344;Motor tic
4345;Vocal tic
4346;Vestibular neuronitis
4347;Brain infarction
4348;Diffuse Lewy body disease
4349;Omphalocele
4350;Hyperlactacidaemia
4351;Coldness
4352;Abortion incomplete
4353;Serum triglycerides increased
4354;Thrombocytosis
4355;Allergic oedema
4356;Infective tenosynovitis
4357;Dry scalp
4358;Rhinitis perennial
4359;Abdominal injury
4360;Eye ulcer
4361;Nephropathy hypertensive
4362;Fungal rash
4363;Ear congestion
4364;Lip haemorrhage
4365;Ear pruritus
4366;Localized erythema
4367;Generalised erythema
4368;Eyelids pruritus
4369;Ventricular failure
4370;Heaviness of head
4371;Nasal itching
4372;Dry cough
4373;Allergic rash
4374;Infected bites
4375;Pelvic pain female
4376;Lipids increased
4377;Carcinoma uterine cervix in situ
4378;Anaemias NEC
4379;Infestation NOS
4380;Blood and lymphatic system disorders
4381;Ear and labyrinth disorders
4382;General disorders and administration site conditions
4383;Gastrointestinal inflammatory conditions
4384;Epidermal and dermal conditions
4385;Endocrine neoplasms malignant and unspecified
4386;Allergic conditions
4387;Salivary gland conditions
4388;Administration site reaction
4389;Sleep disorder
4390;Heart failure signs and symptoms
4391;Muscle tone disorder
4392;Bullous conditions
4393;Ocular sensation disorders
4394;Exfoliative conditions
4395;Gastrointestinal signs and symptoms NEC
4396;Amnestic symptoms
4397;Enterococcal infection
4398;Neisseria infection
4399;Pneumocystis infections
4400;Influenza viral infections
4401;Dyspeptic signs and symptoms
4402;Peritoneal infections
4403;Bone and joint infections
4404;Upper respiratory tract signs and symptoms
4405;Ischaemic coronary artery disorders
4406;Bladder and urethral symptoms
4407;Asthenic conditions
4408;Fluoride increased
4409;Joint related signs and symptoms
4410;Anaemias haemolytic immune
4411;Apocrine and eccrine gland disorders
4412;Skin hemorrhages
4413;Visual colour distortions
4414;Transient cerebrovascular events
4415;Paraesthesias and dysaesthesias
4416;Speech and language abnormalities
4417;Mood alterations with depressive symptoms
4418;Sleep phase rhythm disturbance
4419;Injection site erythema
4420;Embolism arterial (limb)
4421;Paraesthesia NEC
4422;Glucocorticoids decreased
4423;Hand and foot syndrome
4424;Completed suicide
4425;Blood cortisol decreased
4426;Blood cortisol increased
4427;Blood insulin increased
4428;Eye allergy
4429;Non-accidental injury
4430;Pulmonary alveolar haemorrhage
4431;Bucking
4432;Drug ineffective
4433;Blood bicarbonate decreased
4434;Blood alkaline phosphatase increased
4435;Blood amylase increased
4436;Bacteriuria NOS present
4437;Animal scratch
4438;Crohns disease aggravated
4439;Gastrointestinal necrosis
4440;Insomnia exacerbated
4441;Arthropod sting
4442;Arteriopathic disease
4443;Optic nerve cupping
4444;Complication of delivery
4445;Exacerbation of acne
4446;Tongue irritation
4447;Dacryoadenitis acquired
4448;Epilepsy aggravated
4449;Injection site pruritus
4450;Parkinson's disease aggravated
4451;Diverticular perforation
4452;Blood thyroid stimulating hormone increased
4453;Blood oestrogen increased
4454;Blood oestrogen decreased
4455;Blood parathyroid hormone increased
4456;Porphyria non-acute
4457;Blood creatine phosphokinase increased
4458;Reaction to drug excipients
4459;Glomerular filtration rate decreased
4460;Anxiety NEC
4461;High density lipoprotein increased
4462;Nail abnormality NOS
4463;Intentional self-injury
4464;Blood testosterone decreased
4465;Blood testosterone increased
4466;Blood luteinising hormone increased
4467;Blood follicle stimulating hormone increased
4468;Therapeutic response unexpected
4469;CD4 lymphocytes decreased
4470;Blood lactate dehydrogenase increased
4471;Nerve conduction studies abnormal
4472;Bipolar I disorder
4473;Gastroenteritis yersinia
4474;Smear cervix normal
4475;Activated partial thromboplastin time shortened
4476;International normalised ratio increased
4477;International normalised ratio decreased
4478;Blood iron abnormal
4479;Eczema exacerbated
4480;Nasal passage irritation
4481;Pseudo-Bartter syndrome
4482;Osteoarthritis aggravated
4483;Soft tissue inflammation
4484;Dyspnoea exacerbated
4485;Peripheral neuropathy aggravated
4486;Toxic pustuloderma
4487;Thrombocytopenia aggravated
4488;Corneal infiltrates
4489;Venous thrombosis limb
4490;Arthropod bite
4491;Painful red eyes
4492;Exposure to poisonous plant
4493;Blood cholesterol abnormal
4494;Local swelling
4495;Eosinophil count abnormal
4496;Oestrogen deficiency
4497;Blood triglycerides increased
4498;Neutrophil count decreased
4499;Lymphocyte count increased
4500;Application site erythema
4501;Blood prolactin decreased
4502;Sperm count decreased
4503;Application site pruritus
4504;Blood bicarbonate increased
4505;Blood creatinine abnormal
4506;Blood electrolytes abnormal
4507;Blood magnesium decreased
4508;Blood phosphate increased
4509;Blood osmolarity decreased
4510;Blood potassium abnormal
4511;Blood potassium increased
4512;Blood potassium decreased
4513;Exacerbation of hot flushes
4514;Blood calcium abnormal
4515;Blood albumin increased
4516;Blood albumin decreased
4517;Blood creatine phosphokinase abnormal
4518;Blood iron increased
4519;Blood iron decreased
4520;Contrast media reaction
4521;Croup infectious
4522;Local reaction
4523;Cellulitis staphylococcal
4524;Breast cancer invasive NOS
4525;Blood gastrin increased
4526;Tumour flare
4527;Device interaction
4528;Oropharyngeal swelling
4529;Tinnitus aggravated
4530;Dyspepsia aggravated
4531;Nocturia aggravated
4532;Oral mucosal discolouration
4533;Tongue blistering
4534;Oral mucosal blistering
4535;Pain worsened
4536;Corneal calcification
4537;Blood creatine phosphokinase MB increased
4538;Device breakage
4539;Bacterial disease carrier
4540;Blood gonadotrophin increased
4541;Lymphocyte count decreased
4542;Blood creatine increased
4543;pH urine increased
4544;pH urine decreased
4545;Tumor pain
4546;Painful response to normal stimuli
4547;Blood prolactin increased
4548;Drug level changed
4549;Hypoesthesia eye
4550;Nitrogen balance negative
4551;Urine sodium increased
4552;Haemorrhage subcutaneous
4553;Blood triglycerides decreased
4554;Mucosal dryness
4555;Corneal epithelium defect
4556;Gastrointestinal motility disorder
4557;Vaginal wall congestion
4558;Blood bilirubin unconjugated increased
4559;Infection pseudomonas aeruginosa
4560;Blood test abnormal
4561;Conjunctivitis papillary
4562;Temperature regulation disorder
4563;Cognitive deterioration
4564;Incomplete precocious puberty
4565;Subepithelial opacities
4566;Foetal damage
4567;Eyelid function disorder
4568;Limb discomfort
4569;Herpes simplex dermatitis
4570;Insulin autoimmune syndrome
4571;Mastication disorder
4572;Mucosal haemorrhage
4573;Blood insulin decreased
4574;Genital hemorrhage
4575;Libido disorder
4576;Caustic injury
4577;Mechanical complication of implant
4578;Sputum discoloured
4579;Injection site vesicles
4580;Blepharal pigmentation
4581;Injection site hypertrophy
4582;Bladder constriction
4583;Escherichia sepsis
4584;Implant expulsion
4585;Myelosuppression
4586;Hepatitis F
4587;Enterococcal bacteraemia
4588;Peridiverticular abscess
4589;Human herpesvirus 6 infection
4590;Myopericarditis
4591;Complications of transplant surgery
4592;Needle injury
4593;Anaesthetic complication neurological
4594;Dermatitis flare-up
4595;Neonatal infection
4596;Corneal epithelium disorder
4597;Cyanopsia
4598;Lung adenocarcinoma stage I
4599;Lack of spontaneous speech
4600;Feelings of worthlessness
4601;Social avoidant behaviour
4602;Disturbance in sexual arousal
4603;Abnormal sleep-related event
4604;Sleep attacks
4605;Glycosylated haemoglobin decreased
4606;Electrocardiogram change
4607;Electrocardiogram QT corrected interval
4608;Electrocardiogram QT corrected interval prolonged
4609;Electrocardiogram ST segment abnormal
4610;Pancreatic enzymes abnormal
4611;Red blood cells semen positive
4612;Semen volume decreased
4613;Beta 2 microglobulin increased
4614;Beta 2 microglobulin urine increased
4615;Alanine aminotransferase decreased
4616;Alanine aminotransferase abnormal
4617;Alanine aminotransferase normal
4618;Aspartate aminotransferase decreased
4619;Aspartate aminotransferase normal
4620;Bilirubin conjugated increased
4621;Blood uric acid decreased
4622;Culture negative
4623;Blood creatine phosphokinase MM increased
4624;Pulmonary function test decreased
4625;Mean cell volume increased
4626;Antibody NOS negative
4627;Cardioactive drug level above therapeutic
4628;Carotene decreased
4629;Peripheral embolism
4630;Diet refusal
4631;Leukemia secondary
4632;Mental status changes
4633;Vasculitis gastrointestinal
4634;Confusion aggravated
4635;Restlessness aggravated
4636;Constipation aggravated
4637;Vomiting aggravated
4638;Hemorrhoids aggravated
4639;Pancreatitis aggravated
4640;Gynecomastia aggravated
4641;Hepatitis aggravated
4642;Hypercholesterolemia aggravated
4643;Oedema aggravated
4644;Diverticulitis aggravated
4645;Meniere's disease aggravated
4646;Multiple sclerosis relapse
4647;Hematuria aggravated
4648;Urinary frequency aggravated
4649;Back pain aggravated
4650;Fatigue aggravated
4651;Uterine fibroids aggravated
4652;Porphyria aggravated
4653;Spinal haematoma
4654;Fat redistribution
4655;Buccal mucosal roughening
4656;Coronary artery disease aggravated
4657;Pulmonary alveolitis
4658;Orofacial oedema
4659;Accelerated hair loss
4660;Budd-Chiari syndrome
4661;Polymorphonuclear leukocytosis
4662;Acute GVH disease
4663;Headache fullness
4664;Urea increased
4665;Potassium increased
4666;Hemangioma acquired
4667;Raised serum lipid levels
4668;Hyperexcitation
4669;Feeling sick
4670;Acute anaphylaxis
4671;Bad dreams
4672;Blotchy rash
4673;Cold hands & feet
4674;Generalized macular rash
4675;Dizzy spells
4676;Elevated liver enzyme levels
4677;Glaucoma both eyes
4678;Hand rash
4679;Hypertensive
4680;Hyponatraemic
4681;Metastatic pain
4682;Nodal block
4683;Numbness in leg
4684;Persistent dry cough
4685;Postinfarction
4686;Arthritic pains
4687;Pre-menstrual tension syndrome
4688;Raised serum uric acid
4689;Red blotches
4690;Rash both legs
4691;Redness of face
4692;Red neck
4693;Unwell
4694;Bloated feeling
4695;Thrombocytopenic purpura
4696;Anemic
4697;Angioedema of larynx
4698;Acute liver damage
4699;Clonic movements
4700;Hypotensive
4701;Headache occurring
4702;Generalized flushing
4703;Nocturnal confusion
4704;Retrosternal discomfort
4705;Serum osmolality increased
4706;Pituitary hormone deficiency
4707;Serum urea increased
4708;Digoxin effect
4709;Worsening of diabetes
4710;Upper gastrointestinal symptoms
4711;Unresponsive to stimuli
4712;Sore nose
4713;Thromboembolic event
4714;Acute schizophrenia
4715;Thyroid function abnormal
4716;Erythema multiforme minor
4717;Accidental ingestion
4718;Serum prolactin decreased
4719;Serum prolactin increased
4720;Serum testosterone decreased
4721;Serum testosterone increased
4722;Plasma triglycerides increased
4723;Serum bicarbonate increased
4724;Plasma calcium decreased
4725;Plasma creatinine increased
4726;Serum potassium abnormal
4727;Serum sodium abnormal
4728;Thrombosis leg
4729;Gastrointestinal fullness
4730;Clinical flare reaction
4731;Plasma cholesterol increased
4732;Increased agitation
4733;Nasal discomfort
4734;Angina symptom
4735;Bilirubin normal
4736;Gastrointestinal ulcer perforation
4737;Oesophageal stenosis acquired
4738;Serum gastrin increased
4739;Tachycardia nervous
4740;Thrombocytopenia toxic
4741;Hemorrhage symptom
4742;Numbness generalized
4743;Coordination disturbance
4744;Taste salty
4745;Taste sour
4746;Taste sweet
4747;Wave slowing
4748;Posterior subcapsular cataract
4749;Dyschromatopsia
4750;Pharyngolaryngeal pain
4751;Urinary protein increased
4752;Alopecia reversible
4753;Telangiectasis facial
4754;Itch burning
4755;Vitamin B12 absorption decreased
4756;Lip blister
4757;Vascular pain
4758;Myopia transient
4759;Toxic symptom
4760;Application site warmth
4761;Instillation site pain
4762;Hepatitis symptom
4763;Endometrial hypertrophy
4764;Unrest
4765;Reticulocytopenia
4766;Attention concentration difficulty
4767;General discomfort
4768;Injection site warmth
4769;Mental aberration
4770;Carcinogenicity
4771;Oral mucosa sore
4772;Talkativeness
4773;Moaning
4774;Feeling of residual urine
4775;Bilirubin value increased
4776;Serum bilirubin increased
4777;Migration of implant
4778;Microhemorrhage
4779;Black spot
4780;Serum transaminase increased
4781;Lip burning sensation of
4782;Stinging of nose
4783;Amylase decreased
4784;Corneal sensitivity decreased
4785;BCG infection
4786;Non-Q wave MI
4787;Diabetes mellitus inadequate control
4788;Acute fatty liver
4789;Cholestatic liver disease
4790;Drug-induced liver injury
4791;Gallbladder sludge
4792;Granulomatous liver disease
4793;Catheter related infection
4794;Irreversible renal failure
4795;Fluid and electrolyte imbalance
4796;Loss of skin markings
4797;Refractory hypertension
4798;Follicles conjunctivia
4799;Dreamy state
4800;Ground glass appearance
4801;Retinoic acid syndrome
4802;Anxiety symptoms
4803;Bizarre dreams
4804;Morbid dreams
4805;Oppositional
4806;Prothrombin level abnormal
4807;Serum total protein decreased
4808;Carbon dioxide decreased
4809;Osmolality increased
4810;Blood monocytes increased
4811;Blood neutrophil count decreased
4812;Lactate increased
4813;Glucose low
4814;Glucose increased
4815;Urine ketone body present
4816;Antidiuretic hormone abnormality
4817;Oestradiol increased
4818;Albumin low
4819;Potassium low
4820;Sodium decreased
4821;Protein total decreased
4822;Creatine increased
4823;Creatinine normal
4824;Calcium low
4825;Phosphate low
4826;Phosphate increased
4827;Insulin C-peptide decreased
4828;Insulin C-peptide increased
4829;Albumin urine increased
4830;Proarrhythmia
4831;Proarrhythmic effect
4832;Decreased night vision
4833;Gritty feeling in eyes
4834;Ocular stinging
4835;Injection site tenderness
4836;Skin discomfort
4837;Decreased immune responsiveness
4838;Allergic skin reaction
4839;Cold symptoms
4840;Tightness in jaw
4841;Nasal mucus blood tinged
4842;Pharyngo-oral irritation
4843;Hypotension symptomatic
4844;AGEP
4845;Glucose urine increased
4846;Chronic graft versus host disease
4847;Pancolitis
4848;Carditis
4849;Hyperkeratosis
4850;Lung infection
4851;Pruritus NEC
4852;Headache aggravated
4853;Cardiotoxicity
4854;Intracardiac thrombus
4855;Muscle fibrosis
4856;Sympathomimetic effect
4857;Joint range of motion decreased
4858;Estrogenic effect
4859;Electrocardiogram poor R-wave progression
4860;Graft loss
4861;Tooth infection
4862;Occult blood positive
4863;Oral fungal infection
4864;Acute generalized exanthematous pustulosis
4865;Hypoglycaemic seizure
4866;Cytomegalovirus chorioretinitis
4867;Myocardial haemorrhage
4868;Vaginal mucosal blistering
4869;Orthostatic collapse
4870;Venipuncture site bruise
4871;Application site haemorrhage
4872;Application site haematoma
4873;Application site paraesthesia
4874;Application site vesicles
4875;Application site dryness
4876;Retinal toxicity
4877;Sinobronchitis
4878;Scar pain
4879;Cytomegalovirus gastritis
4880;Application site inflammation
4881;Application site papules
4882;Application site pustules
4883;Urinary tract infection fungal
4884;Hernia pain
4885;Spontaneous penile erection
4886;Neutropenic sepsis
4887;Visual brightness
4888;Psychomotor skills impaired
4889;Neonatal hyponatraemia
4890;Spinal epidural hematoma
4891;Food aversion
4892;Injection site joint pain
4893;Nail bed tenderness
4894;Ureterostomy site discomfort
4895;Lipodystrophy acquired
4896;Numbness lips
4897;Respiratory tract infection viral
4898;General physical health deterioration
4899;Abasia
4900;Bone density decreased
4901;Peripheral swelling
4902;Traumatic fracture
4903;Upper respiratory tract inflammation
4904;Peritonsillitis
4905;Post procedural pain
4906;Postoperative wound complication
4907;Iris hyperpigmentation
4908;Blood glucose fluctuation
4909;Muscle tightness
4910;Anal sphincter atony
4911;Abnormal clotting factor
4912;Arterial stenosis limb
4913;Blood bilirubin decreased
4914;Breast discomfort
4915;Cardio-respiratory distress
4916;Raised liver function tests
4917;Gynecological-related pain
4918;Infusion site erythema
4919;Advanced cancer
4920;Skin tear
4921;Anaemia postoperative
4922;Sensorimotor disorder
4923;Performance status decreased
4924;Erythema periorbital
4925;Obnubilation
4926;Rash mouth
4927;Redness gum
4928;Irritation gum
4929;Blood phosphorus decreased
4930;Tumour haemorrhage
4931;Burning anal
4932;Infusion site burning
4933;Alertness decreased
4934;Rectal cramps
4935;Intestinal cramps
4936;Paresthesia of scalp
4937;Cytomegalovirus viraemia
4938;Gingival blister
4939;Urinary bladder polyp
4940;Application site burn
4941;Gastrointestinal cramps
4942;Renal graft loss
4943;Burning mouth
4944;Circadian rhythm sleep disorder
4945;Cerebral arteriosclerosis
4946;Cardiomyopathies
4947;Overactive bladder
4948;Ischemia cerebral
4949;Hypersomnia
4950;Sleeplessness
4951;Transient cerebral ischemia
4952;Mental deficiency
4953;Ovarian neoplasm
4954;Stent occlusion
4955;Impatience
4956;Airway complication of anaesthesia
4957;Agitation postoperative
4958;Idiosyncratic drug reaction
4959;Sudden onset of sleep
4960;Injection site cellulitis
4961;Urogenital haemorrhage
4962;Injection site coldness
4963;Application site eczema
4964;Application site hyperaesthesia
4965;Application site urticaria
4966;Electrocardiogram ST-T change
4967;Blood phosphorus increased
4968;Urine calcium increased
4969;Oropharyngeal candidiasis
4970;Heart alternation
4971;Menstrual cycle prolonged
4972;Venipuncture site hemorrhage
4973;Subileus
4974;Anastomotic leak
4975;Ventricular hypokinesia
4976;Retinal vascular thrombosis
4977;Lupus-like syndrome
4978;Postoperative hypertension
4979;Unwanted awareness during anaesthesia
4980;Platelet aggregation inhibition
4981;Extremity contracture
4982;Band neutrophil count increased
4983;Cytolytic hepatitis
4984;Osteocalcin increased
4985;Post procedural hemorrhage
4986;Incision site haemorrhage
4987;Puncture site haemorrhage
4988;Hyperfibrinogenaemia
4989;Blood pressure inadequately controlled
4990;Nasal mucosal disorder
4991;Pleural infection
4992;Tonic clonic movements
4993;Nasal odour
4994;Pulmonary toxicity
4995;Graft thrombosis
4996;Thoracic vertebral fracture
4997;VIIth nerve paralysis
4998;Infusion site oedema
4999;Adnexa uteri cyst
5000;Uric acid high
5001;Cervical smear test positive
5002;Phosphorus low
5003;Haematotoxicity
5004;Fasting blood glucose increased
5005;Urinary sediment abnormal
5006;Mesenteric ischemia
5007;Idiopathic thrombocytopenia
5008;Catheter site bleeding
5009;Foreign body sensation in eyes
5010;Fundic gland polyp
5011;Descemetitis
5012;Photodermatosis
5013;Aphakic cystoid macular oedema
5014;Psoriatic plaque
5015;Sluggishness
5016;Vitamin B6 deficiency
5017;Prostate cancer metastatic
5018;Eczema herpeticum
5019;Polyradiculoneuritis
5020;Respiratory disorders NEC
5021;Anaphylactic responses
5022;Application and instillation site reactions
5023;Ear disorders NEC
5024;Potassium imbalance
5025;Myasthenia
5026;Reproductive system haemorrhages
5027;Blood urine present
5028;Crystal urine present
5029;Ischemic stroke
5030;Cervix haemorrhage uterine
5031;Red cell distribution width increased
5032;Urine phosphate increased
5033;Primary graft dysfunction
5034;Gastric ulcer helicobacter
5035;Small bowel angioedema
5036;Rhinalgia
5037;Corneal defect
5038;Acute coronary syndrome
5039;Bone marrow toxicity
5040;Postoperative constipation
5041;Acholia
5042;Ureteral spasm
5043;Thyroxine free decreased
5044;Cytokine release syndrome
5045;Immunosuppressant drug level increased
5046;Latent tetany
5047;Haemodynamic instability
5048;Hydrometra
5049;Malignant syndrome NOS
5050;Conjunctival bleb
5051;Corneal decompensation
5052;Conjunctival discharge
5053;Eyelid margin crusting
5054;Ear discomfort
5055;Tympanic membrane hyperaemia
5056;Application site discharge
5057;Application site scab
5058;Application site skin breakdown
5059;Pseudohyperkalaemia
5060;Neutrophil percentage increased
5061;Citrate toxicity
5062;Respiratory tract congestion
5063;Injury asphyxiation
5064;Markedly reduced dietary intake
5065;Myocardial reinfarction
5066;Electrocardiogram ST-T segment abnormal
5067;Colorectal cancer metastatic
5068;Secondary adrenal insufficiency
5069;Intestinal hypomotility
5070;Gastrointestinal hypermotility
5071;Frequent headaches
5072;Diuretic effect
5073;Venoocclusive disease
5074;Chromosomal mutation
5075;Analgesic effect
5076;Anal discomfort
5077;Oral pruritus
5078;Ocular vascular disorder
5079;Musculoskeletal stiffness
5080;Bacteria urine identified
5081;Protein urine present
5082;Musculoskeletal discomfort
5083;Ocular discomfort
5084;Abdominal strangulated hernia
5085;Hyperuricosuria
5086;Bronchial mucus plug
5087;Necrotising colitis
5088;Post procedural discharge
5089;White blood cell count low
5090;Infusion related reaction
5091;Abdominal spasm
5092;Cyclosporine toxicity
5093;Gastrointestinal hypomotility
5094;Uterine cramps
5095;Blanching
5096;Catheter related complication
5097;Hepatic impairment
5098;Catheter blockage
5099;Artificial kidney clotting during dialysis
5100;Catheter site erythema
5101;Catheter site inflammation
5102;Catheter site phlebitis
5103;Haemorrhagic anaemia
5104;Orgasmic sensation decreased
5105;Electrocardiogram repolarisation abnormality
5106;Detachment of retinal pigment epithelium
5107;Flu symptoms
5108;Leukaemia cutis
5109;Catheter site cellulitis
5110;Injection site discolouration
5111;Paresthesia lower limb
5112;Urinary tract signs and symptoms
5113;Large intestine polyp
5114;Upper respiratory tract congestion
5115;Nosocomial pneumonia
5116;Candida sepsis
5117;Viral infections NEC
5118;Catheter site pain
5119;Bacterial infections NEC
5120;Polyomavirus infections
5121;Dysphasia
5122;Febrile bone marrow aplasia
5123;Psychiatric evaluation abnormal
5124;Application site swelling
5125;Infusion site induration
5126;Infusion site pain
5127;Infusion site warmth
5128;Infusion site swelling
5129;Oesophageal discomfort
5130;Infusion site pruritus
5131;Wound complication
5132;Acquired haemophilia
5133;Mitochondrial toxicity
5134;Dacryostenosis acquired
5135;Puncture site reaction
5136;Thyroglobulin increased
5137;Cannula site reaction
5138;Vessel puncture site haemorrhage
5139;Central line infection
5140;Gastrointestinal discomfort
5141;Cardiac discomfort
5142;Cryptococcal cutaneous infection
5143;Dental discomfort
5144;Escherichia bacteraemia
5145;Injection site discomfort
5146;Vanishing bile duct syndrome
5147;Corneal thinning
5148;Increased viscosity of bronchial secretion
5149;Anterior chamber inflammation
5150;Medication residue
5151;Transaminases decreased
5152;Genital burning sensation
5153;Lipase abnormal
5154;Mucosal discolouration
5155;Dysphemia
5156;Infusion site reaction
5157;Mean platelet volume decreased
5158;Body fat disorder
5159;Left ventricular ejection fraction decreased
5160;Altered visual depth perception
5161;Bronchopneumopathy
5162;Vascular occlusion
5163;Infusion site phlebitis
5164;Blood testosterone free increased
5165;Free prostate-specific antigen increased
5166;Blood pancreatic amylase increased
5167;Carotid pulse
5168;Superficial punctate keratopathy
5169;Transaminitis
5170;Prostate examination abnormal
5171;Instillation site irritation
5172;BK virus infection
5173;Medical device discomfort
5174;Vessel puncture site inflammation
5175;Infusion site infection
5176;Pain during injection
5177;Fungus sputum test positive
5178;Neurological disorders NEC
5179;Vascular hypertensive disorders
5180;Vascular hypotensive disorders
5181;Parkinsonian rest tremor
5182;Erythrosis
5183;Abdominal infection
5184;Catheter site infection
5185;Vulvovaginal pruritus
5186;Peripheral sensorimotor neuropathy
5187;Oral pustule
5188;Gaze palsy
5189;Genital discharge
5190;Facial wasting
5191;Temperature intolerance
5192;Connective tissue inflammation
5193;Prostate induration
5194;Spinal cord paralysis
5195;Medical device complication
5196;Eyelid irritation
5197;Paranasal sinus hypersecretion
5198;Anterior chamber pigmentation
5199;Optic disc vascular disorder
5200;Peripheral artery aneurysm
5201;Thromboembolic stroke
5202;QRS axis abnormal
5203;Female sexual dysfunction
5204;Male sexual dysfunction
5205;Cytomegalovirus syndrome
5206;Infusion site inflammation
5207;Corneal irritation
5208;Gastrointestinal ulcer haemorrhage
5209;Neurological examination abnormal
5210;Pancreatitis due to biliary obstruction
5211;Pneumatosis intestinalis
5212;Delayed orgasm
5213;Neonatal tachypnoea
5214;Loss of proprioception
5215;Cerebellar oedema
5216;Allergic exanthema
5217;Cross reactive drug hypersensitivity
5218;Protein allergy
5219;NGU
5220;Haematology test abnormal
5221;Mental impairment disorders
5222;Hepatic lymphoma
5223;Blood methaemoglobin present
5224;Post procedural diarrhea
5225;Breakthrough pain
5226;Monoclonal gammopathy
5227;Malignant neoplasm of ovary
5228;Hypoxic brain damage
5229;Procedural complication
5230;Lymphocyte transformation test positive
5231;Head lag abnormal
5232;Sclerosing encapsulating peritonitis
5233;Long QT syndrome congenital
5234;Muscle enzyme increased
5235;Abdominal sepsis
5236;Post procedural complication
5237;Purple glove syndrome
5238;Ocular icterus
5239;Troponin increased
5240;Troponin I increased
5241;ECG signs of myocardial ischaemia
5242;Orchitis noninfective
5243;Blood bilirubin abnormal
5244;Glabellar reflex abnormal
5245;Peripheral nerve palsy
5246;Tandem gait test abnormal
5247;Oral toxicity
5248;Injection site stinging
5249;Vitamin E decreased
5250;Eyelash discolouration
5251;Eyelash thickening
5252;Hyperalbuminemia
5253;Enterocolitis infectious
5254;Adnexa uteri mass
5255;Scleromalacia
5256;Intentional misuse
5257;Application site discolouration
5258;Brugada syndrome
5259;Incision site complication
5260;Shunt thrombosis
5261;Intestinal stoma complication
5262;Call-Fleming syndrome
5263;Pseudomononucleosis
5264;Infected cyst
5265;Incision site pain
5266;Neutrophilic dermatosis
5267;Brown urine
5268;Drug-induced cough
5269;Clostridium colitis
5270;Melanonychia
5271;Oral mucosal irritation
5272;Bilirubin abnormal
5273;Eyelid pain
5274;Symptomatic hyperlactatemia
5275;Lactic acidosis syndrome
5276;Breast tension
5277;Myoglobinaemia
5278;Hepatitis B reactivation
5279;Staphylococcus aureus bacteremia
5280;Bicytopenia
5281;Application site scar
5282;Suture related complication
5283;Postinfarction angina
5284;Application site excoriation
5285;Gastrointestinal toxicity
5286;Nail pigmentation
5287;Hypothrombinaemia
5288;Asymptomatic hyperlactatemia
5289;Vitamin K decreased
5290;Autonomic nervous system disorders
5291;Failure respiratory
5292;Sudden deafness
5293;Endometrial adenocarcinoma
5294;Application site folliculitis
5295;Infrequent bowel movements
5296;Nail toxicity
5297;Lymphostasis
5298;Epidermal necrosis
5299;Pleuropericarditis
5300;Extremity necrosis
5301;Hoigne's syndrome
5302;Neutropenic infection
5303;Mucosal excoriation
5304;Haemorrhagic urticaria
5305;Skin toxicity
5306;Tobacco withdrawal symptoms
5307;Perinephric collection
5308;Graft dysfunction
5309;Infusion site rash
5310;Urine output increased
5311;Gastric pH decreased
5312;Anti-thyroid antibody positive
5313;Perioral tingling
5314;Absolute neutrophil count decreased
5315;Incision site haematoma
5316;Intermittent headache
5317;Inner ear infection
5318;Drug-induced hypersensitivity syndrome
5319;Severe acute respiratory syndrome
5320;Hydrarthrosis
5321;Colitis pseudomembranous
5322;Vascular resistance systemic
5323;Ileus
5324;Splenic sequestration
5325;Rhinorrhea
5326;Respiration abnormal
5327;Abnormal pigmentation
5328;Sperm concentration
5329;Meningocele
5330;Sarcoma
5331;Detrusor instability
5332;Urticaria localised
5333;Hepatic enzyme decreased
5334;Ischaemic cerebral infarction
5335;Sinusitis bacterial
5336;Recall phenomenon
5337;Graft failure
5338;Freezing phenomenon
5339;Ocular toxicity
5340;Post procedural nausea
5341;Oculogyration
5342;Lymphocytic infiltration
5343;Neuromuscular toxicity
5344;Procedural hypotension
5345;Lipohypertrophy
5346;Poor quality sleep
5347;Increased bronchial secretion
5348;Vaginal erosion
5349;Echoacousia
5350;Cerebrovascular infarction
5351;Oral papilloma
5352;Jaundice hepatocellular
5353;Drug-induced hepatitis
5354;Attention deficit-hyperactivity disorder
5355;Lumbar radiculopathy
5356;Coma diabetic
5357;Infectious peritonitis
5358;Gastrointestinal infection
5359;Change in blood pressure
5360;Major depressive disorder NOS
5361;Tumour invasion
5362;Pigment dispersion syndrome
5363;Impaired fasting glucose
5364;Lichenoid keratosis
5365;Stinging skin
5366;Venomous bite
5367;Urticaria recurrent
5368;Lymphoma cutis
5369;Genitourinary tract infection
5370;Chronic leukaemia
5371;Lipoatrophy
5372;Granulocytosis
5373;Penile swelling
5374;Respiratory disorder neonatal
5375;Acute confusional state
5376;Urine volume
5377;Oral mucosal disorder
5378;Cerebral arterial aneurysm
5379;Abdominal disorder
5380;Abdominal bloating
5381;Epigastric discomfort
5382;B-cell type acute leukaemia
5383;Decreased vibratory sense
5384;Thyroxine decreased
5385;Fibrinogen decreased
5386;Postural orthostatic tachycardia syndrome
5387;Talipes
5388;Abrasion NOS
5389;Fibroadenosis of breast
5390;Mental handicap NOS
5391;Exomphalos
5392;Hepatic insufficiency
5393;Death
5394;Bone mass decreased
5395;Encephalopathy acute
5396;Red man syndrome
5397;Peripheral arterial occlusive disease
5398;Epithelial cells urine
5399;Vasculitis necrotising
5400;Confusion postoperative
5401;Nuchal rigidity
5402;Drug fever
5403;Bronchial hemorrhage
5404;Wandering pacemaker
5405;Bezoar
5406;Breathing abnormally deep
5407;Venous thrombosis deep limb
5408;Blood in stool
5409;Infected eczema
5410;Rhinitis seasonal
5411;Sensitisation
5412;Dysaesthesia pharynx
5413;Increased upper airway secretion
5414;Gastrooesophageal sphincter insufficiency
5415;Procedural hypertension
5416;Pedal pulse decreased
5417;Application site discomfort
5418;Oculo-respiratory syndrome
5419;Breast fibroma
5420;Vaginal contraceptive device expelled
5421;Hip dysplasia
5422;Post procedural hematoma
5423;Brain stem syndrome
5424;Laryngopharyngeal dysesthesia
5425;Retinal pigment epithelial tear
5426;Palmar-plantar erythema
5427;Reflex tachycardia
5428;Peripheral vasodilatation
5429;Extrapulmonary pneumocystosis
5430;Postmenopausal spotting
5431;Puerperal pyrexia
5432;Hepatosplenic T-cell lymphoma
5433;Vascular purpura
5434;Bone marrow aplastic
5435;Adrenal carcinoma
5436;Bile duct neoplasms malignant
5437;Cardiac hypertrophy
5438;Scratch
5439;Metastatic carcinoma
5440;Tinea cruris
5441;Acquired megacolon
5442;Dyspareunia
5443;Hearing loss
5444;Single umbilical artery
5445;Acute depression
5446;Acute haemolytic anaemia
5447;Aortic arteriosclerosis
5448;Skull hypoplasia
5449;Cardiovascular insufficiency
5450;Contraceptive device complication
5451;Cyanotic heart disease
5452;Ovulation disorder
5453;Atypical pneumonia
5454;Solar dermatitis
5455;Myocardial necrosis
5456;Hypervitaminosis D
5457;Exostosis
5458;Anastomotic ulcer
5459;Vaginocele
5460;Feeling abnormal
5461;Cardiopulmonary failure
5462;Posterior capsule opacification
5463;Histiocytosis X of lung
5464;Aortic valve sclerosis
5465;Vagotonia
5466;Paranoia
5467;Paranoid state
5468;Claudication
5469;Ureteral calculus
5470;Aggressive reaction
5471;Bleeding tendency
5472;Breast neoplasm
5473;Acarodermatitis
5474;Body temperature fluctuation
5475;Unresponsive to verbal stimuli
5476;Coagulation test abnormal
5477;Pyramidal tract syndrome
5478;Post procedural oedema
5479;Pelvic haemorrhage
5480;Application site hypersensitivity
5481;Idiopathic pneumonia syndrome
5482;Electrocardiogram QT interval abnormal
5483;Cerebral artery stenosis
5484;Implant site pain
5485;Device malfunction
5486;Tingling of extremity
5487;Post transplant diabetes mellitus
5488;Vegetative dystonia
5489;Implant breakage
5490;Smell alteration
5491;Pseudoaneurysm
5492;Thrombophlebitis superficial
5493;Dysacusis
5494;Deficiency vitamin
5495;Drug dependence
5496;Diverticulosis
5497;Lens opacity
5498;Autism spectrum disorder
5499;Rash papular
5500;Coagulation necrosis
5501;High cholesterol
5502;Colorectal cancer
5503;Edema brain
5504;Pyridoxine deficiency
5505;Sjogren's syndrome
5506;Voice disturbance
5507;Dysphonia
5508;Brain hypoxia
5509;Phototoxicity
5510;Shock insulin
5511;Erythrocytosis
5512;Pneumonia eosinophilic
5513;Renal rickets
5514;Retinal vein thrombosis
5515;Deposit calcium
5516;Application site induration
5517;Orthostatic intolerance
5518;Foetal chromosome abnormality
5519;Pneumocystis jiroveci pneumonia
5520;Retinal aneurysm
5521;Gastrointestinal inflammation
5522;Blood count abnormal
5523;Pelvic discomfort
5524;Oesophageal oedema
5525;Oral mucosal exfoliation
5526;Drug administration error
5527;Renal insufficiency aggravated
5528;Osteoarticular pain
5529;Sudden unexplained death in epilepsy
5530;Coronary stent thrombosis
5531;Eyelash darkening
5532;ST segment elevation myocardial infarction
5533;Nettle rash
5534;Overactivity
5535;Blood cholesterol decreased
5536;Seizure cerebral
5537;Lower limb fracture
5538;Ocular surface disease
5539;Soft tissue necrosis
5540;Chronic kidney disease
5541;Insufficiency renal
5542;Acute renal insufficiency
5543;Sore mouth
5544;Dark circles under eyes
5545;Malignant transformation
5546;Head titubation
5547;Complication of device insertion
5548;Exfoliative rash
5549;Device dislocation
5550;Intestinal diaphragm disease
5551;Infusion site extravasation
5552;Eyelid exfoliation
5553;Vulvovaginal mycotic infection
5554;Allergic bronchospasm
5555;Latent tuberculosis
5556;Application site exfoliation
5557;Antinuclear antibody increased
5558;Circulatory depression
5559;ANA increased
5560;Coital bleeding
5561;Hepatic infiltration eosinophilic
5562;Plateletcrit decreased
5563;Waist circumference increased
5564;Post-traumatic pain
5565;Nephrogenic fibrosing dermopathy
5566;Renal aplasia
5567;Device related infection
5568;Procedural pain
5569;Decompensated cirrhosis
5570;Gout flare
5571;Glioblastoma multiforme
5572;Intraoperative floppy iris syndrome
5573;Arthritis bacterial
5574;Cerebral hypoperfusion
5575;Angiodermatitis
5576;Infusion site hypersensitivity
5577;Infusion site irritation
5578;Vessel puncture site haematoma
5579;Gastrointestinal stoma complication
5580;Application site erosion
5581;Intentional drug misuse
5582;C1 esterase deficiency acquired
5583;Dermatillomania
5584;Ovarian haemorrhage
5585;Prehypertension
5586;Application site cellulitis
5587;Hypoaesthesia facial
5588;Polyomavirus-associated nephropathy
5589;Cystitis viral
5590;Spontaneous haematoma
5591;Puncture site pain
5592;Laryngeal haemorrhage
5593;Cataract conditions
5594;Infusion related pain
5595;Epidermal growth factor receptor decreased
5596;Infusion site paraesthesia
5597;Malignant solid tumour
5598;HCV coinfection
5599;Acute promyelocytic leukaemia differentiation syndrome
5600;Incision site oedema
5601;Supraventricular tachyarrhythmia
5602;Photodamaged skin
5603;Infusion site urticaria
5604;Infusion site thrombophlebitis
5605;Pharyngeal mucositis
5606;Argumentativeness
5607;Ventilator associated pneumonia
5608;Aspermia
5609;Embolus
5610;Benign prostatic hyperplasia
5611;Sarcoma bone
5612;Compulsive personality disorder
5613;Hypophosphatemic rickets
5614;Glucose decreased
5615;Electrolyte disturbance
5616;Peripheral arterial disease
5617;Respiratory distress syndrome
5618;Vessel perforation
5619;Hydrocele
5620;Necrosis tubular kidney
5621;Radiation recall reaction (dermatologic)
5622;Injection site pallor
5623;Anal irritation
5624;Acute dystonia
5625;Acute uveitis
5626;Floppy iris syndrome
5627;Acute cholestatic hepatitis
5628;Acute allograft rejection
5629;Rash recurrent
5630;Mixed liver injury
5631;Administration site infection
5632;Recurrent pulmonary embolism
5633;Systemic allergic reaction
5634;Acute cytolytic hepatitis
5635;Postoperative shivering
5636;Hypoglycaemic unconsciousness
5637;Injection site injury
5638;Post procedural swelling
5639;Dysmorphism
5640;Foetal anticonvulsant syndrome
5641;Prostatic hypertrophy
5642;Acute cardiac toxicity
5643;Opioid naive
5644;Post-tussive vomiting
5645;AML progression
5646;Acute migraine
5647;Balance difficulty
5648;Heart rate abnormal
5649;Suicidal behaviour
5650;Aspiration pneumonitis
5651;Conjunctival hyperemia
5652;AION
5653;Slow speech
5654;Venous thromboembolism
5655;Wound healing normal
5656;Vascular resistance pulmonary increased
5657;Localised intraabdominal fluid collection
5658;Activation syndrome
5659;Procedural nausea
5660;Peritoneal cloudy effluent
5661;Intranasal hypoaesthesia
5662;Catheter thrombosis
5663;Immediate post-injection reaction
5664;Ultrasound ovary abnormal
5665;Injection site dryness
5666;Endotracheal tube obstruction
5667;Uncontrolled hypertension
5668;Genital irritation
5669;Uric acid abnormal
5670;Uric acid increased
5671;Heart racing
5672;Upper abdominal discomfort
5673;Pharmacokinetic interaction
5674;Immune complex reaction
5675;Cytotoxic oedema
5676;Blindness of both eyes, impairment level not further specified
5677;Mineralocorticoid deficiency
5678;Bone spur
5679;Disease coronary artery
5680;Temporal arteritis
5681;Paroxysmal nocturnal dyspnea
5682;Vein distended
5683;Allergic hepatitis
5684;Epidural lipomatosis
5685;Decompensation cardiac
5686;Oculorespiratory syndrome
5687;Herpes simplex hepatitis
5688;Cytarabine syndrome
5689;Genital swelling
5690;Gastrointestinal sounds abnormal
5691;Mucosal pigmentation
5692;Shortened cervix
5693;Chemical phlebitis
5694;Punding
5695;Atherothrombosis
5696;Laryngeal dystonia
5697;Acute overdose
5698;Periungual erythema
5699;Appetite absent
5700;Excessive thirst
5701;Vascular insufficiency of intestine
5702;Vaginismus
5703;Regurgitation
5704;Scar
5705;Anemia vitamin B12 deficiency
5706;Hemorrhagic gastritis
5707;Gout acute
5708;Loose stools
5709;Cyst of kidney
5710;Macromastia
5711;Pulse rate decrease marked
5712;Liver carcinoma
5713;Eosinophil count high
5714;Haemorrhagic erosive gastritis
5715;Parotid gland inflammation
5716;Compulsive sexual behaviour
5717;Compulsive shopping
5718;Oropharyngeal blistering
5719;Oromandibular dystonia
5720;Cholestatic liver injury
5721;Acute liver injury
5722;Mucosal atrophy
5723;Erection prolonged
5724;Hypertransaminasaemia
5725;Arteritic anterior ischaemic optic neuropathy
5726;Tumour compression
5727;Anorectal discomfort
5728;Tingling sensation
5729;Intestinal necrosis
5730;Gastritis erosive
5731;Bulimia nervosa
5732;Hypotonia neonatal
5733;Spinal cord infarction
5734;Medication overuse headache
5735;Bronchopulmonary aspergillosis
5736;Steroid psychosis
5737;Oropharyngeal discomfort
5738;Oropharyngeal pain
5739;Recurrence of neuromuscular blockade
5740;Incessant ventricular tachycardia
5741;Semen analysis abnormal
5742;Respiratory failure aggravated
5743;Cross resistance
5744;Hyposmia
5745;Ageusia
5746;Fluid imbalance
5747;Testicular swelling
5748;Esophagitis ulcerative
5749;Vulva discomfort
5750;Rhinitis allergic
5751;Deafness unilateral
5752;Splenic peliosis
5753;Genital hypoaesthesia
5754;Barium impaction
5755;Tongue pigmentation
5756;Kounis syndrome
5757;Abnormal withdrawal bleeding
5758;Product taste abnormal
5759;Color vision change
5760;Fasting hyperglycaemia
5761;Papulopustular rash
5762;Acute kidney injury
5763;Infusion site reactions
5764;Gastrointestinal tract irritation
5765;Hepatic steatosis
5766;Osteonecrosis of jaw
5767;Dyspnoea at rest
5768;Blood pressure normal
5769;Gout attack
5770;Thrombotic microangiopathy
5771;Nasal inflammation
5772;Pleural fibrosis
5773;Osmotic demyelination syndrome
5774;Infectious pneumonitis
5775;Pulmonary oil microembolism
5776;Application site stinging
5777;Body height decreased
5778;Platelet aggregation increased
5779;Acute phosphate nephropathy
5780;Bacterial colonisation
5781;Destructive thyroiditis
5782;Abdominal aortic rupture
5783;Mucosal bleeding
5784;Subcutaneous bleeding
5785;White matter lesion
5786;Somnolence
5787;Keratitis sicca
5788;Nasopharyngeal carcinoma
5789;Malformation venous
5790;Ulcerative (chronic) proctitis
5791;Vision tubular
5792;Abnormal ejaculation
5793;Hemorrhage cerebral
5794;Upper-airway cough syndrome
5795;HDL cholesterol increased
5796;Penile curvature
5797;Penile haematoma
5798;Respiratory tract oedema
5799;Airway edema
5800;Skin sensitisation
5801;Perioral paraesthesia
5802;Other bacterial diseases
5803;Feeling hot
5804;Mood alteration NOS
5805;Metastatic neoplasm
5806;Metastatic disease
5807;Hypoesthesia tongue
5808;Right ventricular failure
5809;Glucose-6-phosphate dehydrogenase deficiency
5810;Bladder irritability
5811;Urate nephropathy
5812;Leukocytoclastic vasculitis
5813;Hemorrhage vaginal
5814;Lack of libido
5815;Atypical femur fracture
5816;Infection reactivation
5817;Tumour cell mobilisation
5818;Supine hypotension
5819;Major bleed
5820;Minor bleed
5821;Prostatic dysplasia
5822;Macular pigmentation
5823;Posterior reversible encephalopathy syndrome
5824;Hormone-dependent prostate cancer
5825;CNS toxicity
5826;Hypoprothrombinaemia
5827;Hypoventilation
5828;Procedural haemorrhage
5829;Acute enterocolitis
5830;Orthostatic dysregulation
5831;Bilirubin total decreased
5832;Bilirubin total low
5833;Non-cardiogenic pulmonary oedema
5834;Myocardial disorder
5835;Logorrhoea
5836;Catatonic reaction
5837;Tearing eyes
5838;Traumatic injury
5839;Central nervous system haemorrhage
5840;Immune-mediated necrotising myopathy
5841;Operative bleeding
5842;Chalky taste
5843;Hernia hiatal
5844;Bleeding breakthrough
5845;Juvenile arthritis
5846;Peripheral artery stenosis
5847;Myocardial hypertrophy
5848;Advanced breast cancer
5849;Vestibular toxicity
5850;Atypical stress fracture
5851;Cochlear toxicity
5852;Ovulation inhibited
5853;Feeling sad
5854;Arterial thromboembolism
5855;Reversible cerebral vasoconstriction syndrome
5856;Unspecified visual loss
5857;Visual impairment
5858;Food intolerance
5859;Abnormal vision
5860;Labile hypertension
5861;Neutrophilia
5862;Deafness bilateral
5863;Warts
5864;Conjunctival xerosis
5865;Blood calcium decreased
5866;Microembolism
5867;Reproductive toxicity
5868;Intraspinal bleeding
